# The War Over One Pig — Remotion + three.js short (1080x1920, 30 fps, 985 frames / 32.8 s)

25 shots (avg ~1.3 s) with 4-frame dissolves, dense grass, sun shafts, DOF, rim light.
Voice-over: `public/voice.mp3` (ElevenLabs, 32.84 s). Word timings: `src/story/words.ts`. Shot list: `src/story/shots.tsx`.

## Render (on your own PC with a GPU — Node 20+ and Chrome)
    npm install
    npm run studio            # live preview, scrub the timeline
    npm run render-preview    # half-res check (fast)
    npm run render            # final 1080x1920 mp4 (voice-over included)
If your Chrome gives a blank/black frame, try `--gl=swangle` instead of `--gl=angle` in package.json.

## Look controls
- Per shot: camera keys, DOF (focus/range/bokeh), light preset (day / golden / night) — `src/story/shots.tsx`
- Characters: `LOOKS` in `src/engine/cast.tsx`, faces/poses in `src/engine/toon.ts`
- Captions sit at 70% of frame height; the whole view is shifted up 11% so subjects stay in the upper ~70% (see `Rig` in `src/ShotView.tsx`)
- Post chain is hand-built (`src/engine/post.tsx`); the stock @react-three/postprocessing wrapper rendered blank under Remotion.

## Notes
- Grass blades are skipped near the camera path and around characters (see grassSkip in ShotView.tsx).
- Shots overlap by 4 frames for the dissolve (Short.tsx).

## Not done yet
Music bed and sound effects (gunshot at ~8.4 s, stamp at ~29.3 s), a second polish pass on the ships and hall.
