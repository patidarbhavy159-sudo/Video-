set -e
cd /home/claude/pig
for p in "1 0-3" "2 4-7"; do set -- $p; npx remotion render src/index.ts PigWar out/pt$1.mp4 --frames=$2 --muted --codec=h264 --crf=22 --pixel-format=yuv420p --gl=swangle --concurrency=1 --scale=0.25 --browser-executable=/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell > out/pt$1.log 2>&1; done
printf "file 'out/pt%s.mp4'\n" 1 2 > out/list.txt
ffmpeg -v error -y -f concat -safe 0 -i out/list.txt -i public/voice.mp3 -map 0:v -map 1:a -c:v copy -c:a aac -shortest out/pipetest.mp4
ffprobe -v error -show_entries stream=codec_type,width,height,nb_frames -of default=nw=1 out/pipetest.mp4
echo PIPE_DONE
