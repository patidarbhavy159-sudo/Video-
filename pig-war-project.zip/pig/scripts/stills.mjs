import { bundle } from "@remotion/bundler";
import { selectComposition, renderStill } from "@remotion/renderer";
import path from "node:path";
const frames = (process.env.FRAMES || "24,100,200,252,320,385,440,520,620,750,825,890,955").split(",").map(Number);
const scale = Number(process.env.SCALE || 0.35);
const opts = { browserExecutable: process.env.CHROME_PATH, chromiumOptions: { gl: "swangle" }, timeoutInMilliseconds: 120000, onBrowserLog: (l) => { if (/error|warn|fail/i.test(l.text) && !/swiftshader|deprecated/i.test(l.text)) console.log("[browser]", l.text.slice(0, 300)); } };
const serveUrl = await bundle({ entryPoint: path.resolve("src/index.ts"), publicDir: path.resolve("public") });
const comp = await selectComposition({ serveUrl, id: "PigWar", ...opts });
for (const f of frames) {
  const t0 = Date.now();
  try { await renderStill({ composition: comp, serveUrl, frame: f, scale, output: `out/still_${String(f).padStart(3, "0")}.png`, ...opts }); console.log("frame", f, "ok", ((Date.now() - t0) / 1000).toFixed(1) + "s"); }
  catch (e) { console.log("frame", f, "FAILED", String(e).slice(0, 400)); }
}
console.log("DONE");
