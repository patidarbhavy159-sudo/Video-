import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
export type Word = { text: string; start: number; end?: number };
// One word at a time, hard swap (matches the sample). Last child of the root so it sits above the lens blur.
export const Captions: React.FC<{ words: Word[]; group?: number }> = ({ words, group = 1 }) => {
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  const t = frame / fps;
  const idx = words.findIndex((w, i) => t >= w.start && t < (w.end ?? words[i + 1]?.start ?? w.start + 0.3));
  if (idx < 0) return null;
  const first = Math.floor(idx / group) * group;
  const line = words.slice(first, first + group);
  const size = width * 0.08;
  return (
    <AbsoluteFill style={{ justifyContent: "flex-start", alignItems: "center" }}>
      <div style={{ position: "absolute", top: height * 0.7, transform: "translateY(-50%)", width: width * 0.9, textAlign: "center",
        fontFamily: "Arial Black, Impact, sans-serif", fontWeight: 900, fontSize: size, color: "white",
        WebkitTextStroke: `${size * 0.12}px black`, paintOrder: "stroke fill", textTransform: "uppercase", textShadow: `0 ${size * 0.05}px ${size * 0.08}px rgba(0,0,0,0.45)` }}>
        {line.map((w, i) => <span key={first + i} style={{ opacity: first + i <= idx ? 1 : 0 }}>{w.text}{" "}</span>)}
      </div>
    </AbsoluteFill>
  );
};
