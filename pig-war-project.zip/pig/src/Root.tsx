import React from "react";
import { Composition } from "remotion";
import { Short, TOTAL_FRAMES } from "./Short";
export const Root: React.FC = () => <Composition id="PigWar" component={Short} width={1080} height={1920} fps={30} durationInFrames={TOTAL_FRAMES} />;
