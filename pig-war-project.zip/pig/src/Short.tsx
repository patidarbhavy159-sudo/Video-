import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile } from "remotion";
import { ShotView } from "./ShotView";
import { Captions } from "./Captions";
import { SHOTS } from "./story/shots";
import { WORDS } from "./story/words";
export const TOTAL_FRAMES = 985;
export const Short: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("voice.mp3")} />
    {SHOTS.map((s, i) => { const pre = i === 0 ? 0 : 4; return <Sequence key={s.id} from={s.start - pre} durationInFrames={s.len + pre} name={s.id}><ShotView shot={s} pre={pre} /></Sequence>; })}
    <Captions words={WORDS} />
  </AbsoluteFill>
);
