import React, { useLayoutEffect, useMemo } from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { useThree } from "@react-three/fiber";
import * as THREE from "three";
import { camAt, CamPose } from "./engine/camera";
import { Sky, Lights, PRE } from "./engine/lights";
import { Terrain, Water, Clouds, Trees, Grass, Shafts, heightFn } from "./engine/world";
import { Char, Crowd, Stone } from "./engine/cast";
import { Fx } from "./engine/fx";
import { Hall } from "./engine/build";
import { Motes } from "./engine/motes";
import { Post } from "./engine/post";
import { lerp } from "./engine/util";
import type { ShotSpec } from "./story/shots";
import { farmDirt } from "./story/shots";

const Rig: React.FC<{ cam: CamPose; w: number; h: number }> = ({ cam, w, h }) => {
  const { camera } = useThree();
  useLayoutEffect(() => {
    const c = camera as THREE.PerspectiveCamera;
    c.position.copy(cam.pos); c.up.set(Math.sin(cam.roll), Math.cos(cam.roll), 0); c.lookAt(cam.tgt);
    c.fov = cam.fov; c.near = 0.1; c.far = 3000; c.setViewOffset(w, h, 0, Math.round(h * 0.11), w, h); c.updateProjectionMatrix(); c.updateMatrixWorld();
  });
  return null;
};
export const ShotView: React.FC<{ shot: ShotSpec; pre?: number }> = ({ shot, pre = 0 }) => {
  const raw = useCurrentFrame();
  const f = Math.max(0, raw - pre);
  const fade = pre > 0 ? Math.min(1, (raw + 1) / pre) : 1;
  const { width, height } = useVideoConfig();
  const cam = camAt(shot.cam, f, shot.kicks);
  const hf = useMemo(() => heightFn(shot.loc), [shot.loc]);
  // keep grass blades out of the lens: skip blades near any point the camera passes through
  const camPts = useMemo(() => Array.from({ length: Math.ceil(shot.len / 6) + 1 }, (_, i) => camAt(shot.cam, i * 6, shot.kicks).pos), [shot]);
  const clearPts = useMemo(() => shot.cast.filter((c) => c.who !== "pig").flatMap((c) => [c.pos, ...(c.to ? [c.to] : [])]), [shot]);
  const grassSkip = useMemo(() => (x: number, z: number) => camPts.some((p) => (p.x - x) ** 2 + (p.z - z) ** 2 < 3.2 * 3.2) || clearPts.some((p) => (p[0] - x) ** 2 + (p[2] - z) ** 2 < 1.0) || (shot.id.startsWith("grave") && x * x + (z + 3) * (z + 3) < 4.6 * 4.6) || (shot.loc === "farm" && farmDirt(x, z) > 0.3), [camPts, clearPts, shot]);
  const tint = PRE[shot.light].tint;
  const focus = lerp(shot.dof.f0, shot.dof.f1, Math.min(1, f / Math.max(1, shot.len - 1)));
  const flash = shot.flash?.find((fl) => f >= fl.f && f < fl.f + fl.len);
  const isHall = shot.loc === "hall";
  const water = shot.loc === "island" || shot.loc === "beach" || shot.loc === "sea" || shot.loc === "camp";
  const avoid = shot.loc === "farm" ? [{ x: -5, z: -21, r: 9 }, { x: 4, z: -11, r: 9 }] : [];
  return (
    <AbsoluteFill style={{ background: "#000", opacity: fade }}>
      <ThreeCanvas width={width} height={height} shadows dpr={1} gl={{ antialias: false, powerPreference: "high-performance" }} camera={{ fov: cam.fov, near: 0.1, far: 3000, position: cam.pos.toArray() }}>
        <Rig cam={cam} w={width} h={height} />
        <Sky name={shot.light} cam={cam} />
        <Lights name={shot.light} focus={shot.focus} size={shot.shadow} extra={shot.extraLights} />
        {!isHall && <Terrain loc={shot.loc} light={shot.light} dirtAt={shot.loc === "farm" ? farmDirt : undefined} />}
        {water && <Water light={shot.light} f={f} />}
        {!isHall && <><Clouds light={shot.light} seed={shot.id.length} f={f} speed={0.05} /><Clouds light={shot.light} seed={shot.id.length + 7} f={f} speed={0.13} lift={25} /></>}
        {isHall && <Hall light={shot.light} />}
        {["meadow", "farm", "hill", "beach"].includes(shot.loc) && <Grass loc={shot.loc} cx={shot.focus[0]} cz={shot.focus[2] + 2} radius={15} n={26000} seed={shot.id.length * 13} light={shot.light} skip={grassSkip} />}
        {!isHall && <Shafts f={f} cam={cam} light={shot.light} focus={shot.focus} />}
        {shot.trees && <Trees loc={shot.loc} light={shot.light} avoid={avoid} {...shot.trees} />}
        {shot.scene?.(f, hf)}
        {shot.cast.filter((c) => !c.vis || (f >= c.vis[0] && f < c.vis[1])).map((c, i) => <Char key={i} item={c} f={f} cam={cam} tint={tint} groundY={hf(c.pos[0], c.pos[2])} kicks={shot.kicks} rim={shot.light !== "night"} idx={i} />)}
        {shot.id.startsWith("grave") && <Stone pos={[0, 0, -1.6]} cam={cam} tint={tint} groundY={hf(0, -1.6)} />}
        {shot.crowds?.map((c, i) => <Crowd key={i} spec={c} f={f} cam={cam} tint={tint} heightAt={hf} />)}
        {shot.fx && <Fx items={shot.fx} f={f} cam={cam} />}
        <Motes f={f} cam={cam} night={shot.light === "night"} n={isHall ? 40 : 70} />
        <Post focus={focus} range={shot.dof.range} bokeh={shot.dof.bokeh} outH={height} />
      </ThreeCanvas>
      {flash && <AbsoluteFill style={{ background: "#fff", opacity: 0.85 * (1 - (f - flash.f) / flash.len) }} />}
    </AbsoluteFill>
  );
};
