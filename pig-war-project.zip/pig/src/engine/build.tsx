import React, { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import type { V3 } from "./camera";
import { logsTex, planksTex, flagTex, tilesTex, canvasClothTex, dirtTex } from "./paint";
import { mulberry32 } from "./util";

const Std = (c: string, r = 0.8, m = 0) => <meshStandardMaterial color={c} roughness={r} metalness={m} />;

export const Cabin: React.FC<{ pos: V3; rot?: number }> = ({ pos, rot = 0 }) => {
  const logs = useMemo(() => logsTex([3, 1.2]), []), planks = useMemo(() => planksTex([3, 1], "#a87444"), []);
  return (
    <group position={pos} rotation={[0, rot, 0]}>
      <mesh position={[0, 1.5, 0]} castShadow receiveShadow><boxGeometry args={[6.4, 3, 4.6]} /><meshStandardMaterial map={logs} roughness={0.9} /></mesh>
      {[-1, 1].map((s) => <mesh key={s} position={[0, 4.0, s * 1.35]} rotation={[s * 0.62, 0, 0]} castShadow><boxGeometry args={[7.2, 0.25, 3.0]} /><meshStandardMaterial map={planks} roughness={0.9} /></mesh>)}
      <mesh position={[0, 3.4, 0]} castShadow><boxGeometry args={[6.4, 0.9, 0.2]} />{Std("#7a5230")}</mesh>
      <mesh position={[2.3, 4.2, -0.8]} castShadow><boxGeometry args={[0.9, 3.0, 0.9]} />{Std("#9a8a7a")}</mesh>
      <mesh position={[-0.6, 1.1, 2.32]}><boxGeometry args={[1.2, 2.2, 0.12]} />{Std("#5e3a1b")}</mesh>
      <mesh position={[1.8, 1.7, 2.32]}><boxGeometry args={[1.0, 0.9, 0.1]} />{Std("#a8d4e8", 0.2)}</mesh>
    </group>
  );
};
export const RailFence: React.FC<{ a: V3; b: V3; hf: (x: number, z: number) => number }> = ({ a, b, hf }) => {
  const len = Math.hypot(b[0] - a[0], b[2] - a[2]), n = Math.max(2, Math.round(len / 2.2)), ang = Math.atan2(b[0] - a[0], b[2] - a[2]);
  const parts = [];
  for (let i = 0; i <= n; i++) { const t = i / n, x = a[0] + (b[0] - a[0]) * t, z = a[2] + (b[2] - a[2]) * t, y = hf(x, z); parts.push(<mesh key={"p" + i} position={[x, y + 0.6, z]} castShadow><boxGeometry args={[0.16, 1.3, 0.16]} />{Std("#7a5230")}</mesh>); }
  for (let i = 0; i < n; i++) { const t = (i + 0.5) / n, x = a[0] + (b[0] - a[0]) * t, z = a[2] + (b[2] - a[2]) * t, y = hf(x, z); for (const hh of [0.45, 0.95]) parts.push(<mesh key={`r${i}${hh}`} position={[x, y + hh, z]} rotation={[0, ang, 0]} castShadow><boxGeometry args={[0.1, 0.1, len / n + 0.05]} />{Std("#8a6038")}</mesh>); }
  return <>{parts}</>;
};
export const Potatoes: React.FC<{ center: V3; size: [number, number]; rows: number; hf: (x: number, z: number) => number }> = ({ center, size, rows, hf }) => {
  const mounds = useRef<THREE.InstancedMesh>(null!), plants = useRef<THREE.InstancedMesh>(null!);
  const per = 10;
  useLayoutEffect(() => {
    const r = mulberry32(14), m = new THREE.Matrix4(); let k = 0;
    for (let i = 0; i < rows; i++) {
      const x = center[0] - size[0] / 2 + (i / (rows - 1)) * size[0]; m.compose(new THREE.Vector3(x, center[1] + 0.14, center[2]), new THREE.Quaternion(), new THREE.Vector3(0.9, 0.35, size[1] / 2)); mounds.current.setMatrixAt(i, m);
      for (let j = 0; j < per; j++) { const z = center[2] - size[1] / 2 + ((j + 0.5) / per) * size[1], s = 0.42 + r() * 0.25; m.compose(new THREE.Vector3(x + (r() - 0.5) * 0.15, center[1] + 0.4, z), new THREE.Quaternion(), new THREE.Vector3(s, s * 0.7, s)); plants.current.setMatrixAt(k++, m); }
    }
    mounds.current.instanceMatrix.needsUpdate = plants.current.instanceMatrix.needsUpdate = true;
  }, []);
  return (
    <>
      <instancedMesh ref={mounds} args={[undefined, undefined, rows]} receiveShadow frustumCulled={false}><sphereGeometry args={[1, 10, 6]} /><meshStandardMaterial color="#9a5528" roughness={1} /></instancedMesh>
      <instancedMesh ref={plants} args={[undefined, undefined, rows * per]} castShadow frustumCulled={false}><icosahedronGeometry args={[1, 1]} /><meshStandardMaterial color="#3f9a34" roughness={0.9} flatShading /></instancedMesh>
    </>
  );
};
export const Flag: React.FC<{ pos: V3; kind: "us" | "uk"; f: number; h?: number }> = ({ pos, kind, f, h = 9 }) => {
  const tex = useMemo(() => flagTex(kind), [kind]);
  const geo = useRef<THREE.PlaneGeometry>(null!);
  useLayoutEffect(() => {
    const p = geo.current.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < p.count; i++) { const x = p.getX(i) + 1.8; p.setZ(i, Math.sin(x * 2.2 - f * 0.28) * 0.18 * (x / 3.6) + Math.sin(x * 1.1 - f * 0.17) * 0.1); }
    p.needsUpdate = true; geo.current.computeVertexNormals();
  }, [f]);
  return (
    <group position={pos}>
      <mesh position={[0, h / 2, 0]} castShadow><cylinderGeometry args={[0.07, 0.1, h, 8]} />{Std("#d8d8d8", 0.4, 0.3)}</mesh>
      <mesh position={[0, h + 0.1, 0]}><sphereGeometry args={[0.16, 10, 8]} />{Std("#e8c34a", 0.3, 0.6)}</mesh>
      <mesh position={[1.9, h - 1.1, 0]} castShadow><planeGeometry ref={geo} args={[3.6, 2.2, 14, 8]} /><meshStandardMaterial map={tex} side={THREE.DoubleSide} roughness={0.9} /></mesh>
    </group>
  );
};
export const Tent: React.FC<{ pos: V3; rot?: number; kind: "us" | "uk"; s?: number }> = ({ pos, rot = 0, kind, s = 1 }) => {
  const cloth = useMemo(() => canvasClothTex(kind === "us" ? "#efe6cc" : "#f6f0e2"), [kind]);
  return (
    <group position={pos} rotation={[0, rot, 0]} scale={s}>
      {kind === "us"
        ? <mesh position={[0, 1.15, 0]} rotation={[0, 0, Math.PI / 2]} castShadow receiveShadow><cylinderGeometry args={[1.5, 1.5, 3.2, 3]} /><meshStandardMaterial map={cloth} roughness={1} /></mesh>
        : <><mesh position={[0, 1.2, 0]} castShadow receiveShadow><cylinderGeometry args={[0.15, 1.7, 2.4, 14]} /><meshStandardMaterial map={cloth} roughness={1} /></mesh><mesh position={[0, 0.3, 0]}><cylinderGeometry args={[1.72, 1.74, 0.5, 14]} />{Std("#c8202f", 0.9)}</mesh></>}
    </group>
  );
};
export const Cannon: React.FC<{ pos: V3; rot?: number; s?: number }> = ({ pos, rot = 0, s = 1 }) => {
  const wheel = (z: number) => <group key={z} position={[0, 0.55, z]}><mesh rotation={[Math.PI / 2, 0, 0]} castShadow><torusGeometry args={[0.55, 0.09, 8, 20]} />{Std("#6a4524")}</mesh><mesh rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.12, 0.12, 0.2, 10]} />{Std("#2b2b2f", 0.5, 0.5)}</mesh><mesh rotation={[0, 0, 0]}><boxGeometry args={[1.0, 0.07, 0.07]} />{Std("#6a4524")}</mesh><mesh><boxGeometry args={[0.07, 1.0, 0.07]} />{Std("#6a4524")}</mesh></group>;
  return (
    <group position={pos} rotation={[0, rot, 0]} scale={s}>
      {[-0.55, 0.55].map(wheel)}
      <mesh position={[0, 0.85, 0]} castShadow><boxGeometry args={[1.5, 0.3, 0.9]} />{Std("#6a4524")}</mesh>
      <mesh position={[0.35, 1.15, 0]} rotation={[0, 0, Math.PI / 2 - 0.12]} castShadow><cylinderGeometry args={[0.2, 0.3, 2.0, 14]} />{Std("#2b2b30", 0.35, 0.7)}</mesh>
      <mesh position={[1.4, 1.2, 0]} rotation={[0, 0, Math.PI / 2]}><torusGeometry args={[0.2, 0.05, 6, 14]} />{Std("#1c1c20", 0.4, 0.7)}</mesh>
      {[0, 1, 2].map((i) => <mesh key={i} position={[-1.2 + i * 0.28, 0.2, 1.0]} castShadow><sphereGeometry args={[0.13, 10, 8]} />{Std("#2b2b30", 0.4, 0.6)}</mesh>)}
    </group>
  );
};
export const Campfire: React.FC<{ pos: V3; f: number }> = ({ pos, f }) => {
  const k = 1 + Math.sin(f * 0.9) * 0.12 + Math.sin(f * 1.7) * 0.08;
  return (
    <group position={pos}>
      {[0, 1.05, 2.1].map((a) => <mesh key={a} position={[Math.cos(a) * 0.25, 0.12, Math.sin(a) * 0.25]} rotation={[Math.PI / 2, 0, a]}><cylinderGeometry args={[0.08, 0.08, 0.9, 6]} />{Std("#4a2f18")}</mesh>)}
      <mesh position={[0, 0.5 * k, 0]} scale={[1, k, 1]}><coneGeometry args={[0.32, 1.0, 8]} /><meshBasicMaterial color="#ff8a1e" toneMapped={false} /></mesh>
      <mesh position={[0, 0.38 * k, 0]} scale={[1, k, 1]}><coneGeometry args={[0.18, 0.7, 8]} /><meshBasicMaterial color="#ffe27a" toneMapped={false} /></mesh>
    </group>
  );
};
export const Rowboat: React.FC<{ pos: V3; rot?: number; f: number }> = ({ pos, rot = 0, f }) => (
  <group position={[pos[0], pos[1] + Math.sin(f * 0.12 + pos[0]) * 0.05, pos[2]]} rotation={[0, rot, Math.sin(f * 0.1 + pos[2]) * 0.03]}>
    <mesh position={[0, 0.35, 0]} scale={[1, 0.45, 0.42]} castShadow><sphereGeometry args={[2.6, 18, 10, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2]} /><meshStandardMaterial color="#7a5230" roughness={0.8} side={THREE.DoubleSide} /></mesh>
    <mesh position={[0, 0.58, 0]} scale={[1, 0.02, 0.42]}><sphereGeometry args={[2.62, 18, 4]} />{Std("#e8dcc0")}</mesh>
    {[-0.8, 0.8].map((z) => <group key={z}><mesh position={[0, 0.85, z]} rotation={[Math.PI / 2 + 0.5, 0, 0]}><cylinderGeometry args={[0.04, 0.04, 2.0, 6]} />{Std("#d8c9a8")}</mesh></group>)}
  </group>
);
export const Ship: React.FC<{ pos: V3; rot?: number; f: number; s?: number }> = ({ pos, rot = 0, f, s = 1 }) => {
  const sail = useMemo(() => canvasClothTex("#f4eedd"), []);
  const hull = useMemo(() => { const sh = new THREE.Shape(); sh.moveTo(-9, 0); sh.lineTo(8, 0); sh.quadraticCurveTo(12, 1.2, 14, 3.2); sh.lineTo(-10, 3.0); sh.lineTo(-9, 0); const g = new THREE.ExtrudeGeometry(sh, { depth: 4.4, bevelEnabled: true, bevelSize: 0.5, bevelThickness: 0.5, bevelSegments: 2 }); g.translate(0, 0, -2.2); return g; }, []);
  return (
    <group position={[pos[0], pos[1] + Math.sin(f * 0.07) * 0.18, pos[2]]} rotation={[0, rot, Math.sin(f * 0.06) * 0.025]} scale={s}>
      <mesh geometry={hull} position={[0, 0.2, 0]} castShadow receiveShadow><meshStandardMaterial color="#1f2433" roughness={0.6} /></mesh>
      <mesh position={[2, 1.9, 0]}><boxGeometry args={[22, 0.35, 5.2]} />{Std("#f2ead6", 0.6)}</mesh>
      {[-7, -3, 1, 5, 9].map((x) => [-1, 1].map((z) => <mesh key={`${x}${z}`} position={[x, 2.4, z * 2.75]}><boxGeometry args={[1.0, 0.7, 0.1]} />{Std("#0e0e12")}</mesh>))}
      {[-4.5, 1.5, 7].map((x, i) => (
        <group key={x} position={[x, 3.2, 0]}>
          <mesh position={[0, 7 - i * 0.5, 0]} castShadow><cylinderGeometry args={[0.16, 0.22, 14 - i, 8]} />{Std("#6a4524")}</mesh>
          {[0, 1].map((r) => <mesh key={r} position={[0.45 + Math.sin(f * 0.05 + r) * 0.04, 4.2 + r * 5 - i * 0.4, 0]} castShadow><planeGeometry args={[6.4 - r * 1.6, 4.2]} /><meshStandardMaterial map={sail} side={THREE.DoubleSide} roughness={1} /></mesh>)}
        </group>
      ))}
      <mesh position={[-9.4, 6, 0]}><planeGeometry args={[0.1, 0.1]} /><meshBasicMaterial /></mesh>
    </group>
  );
};
export const Hall: React.FC<{ light: string }> = () => {
  const tiles = useMemo(() => tilesTex([12, 12], "#e4d9c2", "#b8aa8e"), []);
  const wall = useMemo(() => planksTex([6, 2], "#d6c9a8"), []);
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow><planeGeometry args={[40, 40]} /><meshStandardMaterial map={tiles} roughness={0.5} /></mesh>
      <mesh position={[0, 7, -9]} receiveShadow><boxGeometry args={[40, 14, 0.5]} /><meshStandardMaterial map={wall} color="#d8caa4" roughness={0.9} /></mesh>
      <mesh position={[0, 0.05, -2]} receiveShadow rotation={[-Math.PI / 2, 0, 0]}><planeGeometry args={[4.2, 14]} />{Std("#a8182a", 1)}</mesh>
      {[-9, -5, 5, 9].map((x) => <group key={x} position={[x, 0, -8]}><mesh position={[0, 6, 0]} castShadow><cylinderGeometry args={[0.7, 0.8, 12, 16]} />{Std("#efe6d0", 0.5)}</mesh><mesh position={[0, 12.2, 0]}><boxGeometry args={[2.2, 0.5, 2.2]} />{Std("#e8c34a", 0.4, 0.5)}</mesh></group>)}
      {[-1, 1].map((s) => <mesh key={s} position={[s * 5.2, 5, -8.6]} castShadow><boxGeometry args={[3.2, 10, 0.4]} />{Std("#9a1424", 0.9)}</mesh>)}
      <mesh position={[0, 8.5, -8.6]}><boxGeometry args={[6.4, 4.4, 0.3]} />{Std("#e8c34a", 0.5, 0.4)}</mesh>
      <mesh position={[0, 8.5, -8.4]}><boxGeometry args={[5.6, 3.6, 0.3]} />{Std("#2a3a5c", 0.8)}</mesh>
      <mesh position={[0, 0.55, -6.4]} castShadow receiveShadow><boxGeometry args={[4.4, 1.1, 1.6]} />{Std("#6a3a1c", 0.55)}</mesh>
      <mesh position={[0, 1.12, -6.4]}><boxGeometry args={[4.6, 0.1, 1.8]} />{Std("#2a5a3a", 0.9)}</mesh>
    </group>
  );
};
