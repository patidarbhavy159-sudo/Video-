import * as THREE from "three";
import { smootherstep, lerp } from "./util";
export type V3 = [number, number, number];
export type Key = { f: number; p: V3; t: V3; fov: number; roll?: number };
export type CamPose = { pos: THREE.Vector3; tgt: THREE.Vector3; fov: number; roll: number };

// Glide between keys with smootherstep, then add a creeping push so no hold is ever static.
export function camAt(keys: Key[], f: number, kicks: number[] = []): CamPose {
  let a = keys[0], b = keys[0];
  const last = keys[keys.length - 1];
  if (f >= last.f) { a = b = last; }
  else if (f > keys[0].f) {
    for (let i = 0; i < keys.length - 1; i++) if (f >= keys[i].f && f < keys[i + 1].f) { a = keys[i]; b = keys[i + 1]; break; }
  }
  const t = a === b ? 0 : smootherstep((f - a.f) / (b.f - a.f));
  const pos = new THREE.Vector3(lerp(a.p[0], b.p[0], t), lerp(a.p[1], b.p[1], t), lerp(a.p[2], b.p[2], t));
  const tgt = new THREE.Vector3(lerp(a.t[0], b.t[0], t), lerp(a.t[1], b.t[1], t), lerp(a.t[2], b.t[2], t));
  const fov = lerp(a.fov, b.fov, t);
  const roll = lerp(a.roll ?? 0, b.roll ?? 0, t);
  const fwd = tgt.clone().sub(pos); const dist = fwd.length(); fwd.normalize();
  pos.addScaledVector(fwd, 0.0022 * dist * f);
  const right = new THREE.Vector3().crossVectors(fwd, new THREE.Vector3(0, 1, 0)).normalize();
  pos.addScaledVector(right, Math.sin(f * 0.035) * 0.004 * dist);
  for (const k of kicks) {
    const d = f - k;
    if (d >= 0 && d < 7) {
      const amp = 0.35 * Math.pow(0.6, d) * (d % 2 ? -1 : 1);
      pos.addScaledVector(right, amp * 0.4); pos.y += amp * 0.3;
    }
  }
  return { pos, tgt, fov, roll };
}
