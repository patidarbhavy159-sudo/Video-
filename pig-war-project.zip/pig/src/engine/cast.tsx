import React, { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import type { V3, CamPose } from "./camera";
import { paintChar, paintPig, paintStone, Look, Expr, PoseName, Part, SHOULDER, W, H, FEET, TOP } from "./toon";
import { toTex, textTex, canvasClothTex } from "./paint";
import { smootherstep, lerp, mulberry32 } from "./util";

export const LOOKS: Record<string, Look> = {
  mac: { hat: "cap", hatColor: "#c8202f", top: "#f2c230", bib: "#2f5fb8", text: "MAC" },
  griffin: { hat: "tophat", hatColor: "#7a1d1d", top: "#7a5233", coat: true, buttons: "#e8c34a", mustache: "#3a2a1a", trim: "#5a3a20" },
  kaiser: { hat: "pickel", hatColor: "#d9dde6", top: "#26385c", coat: true, trim: "#c8202f", buttons: "#e8c34a", whiskers: "#f2f2f2", mustache: "#f2f2f2", sash: "#e9e9e9" },
  usA: { straps: true, hat: "kepi", hatColor: "#1f3d8f", top: "#1f3d8f", coat: true, trim: "#e8c34a", buttons: "#e8c34a" },
  usB: { straps: true, hat: "kepi", hatColor: "#2a4aa0", top: "#27408a", coat: true, trim: "#9fb4e8", buttons: "#e8c34a", hair: "#3a2a1a", hairStyle: "side" },
  usC: { straps: true, hat: "kepi", hatColor: "#1b3478", top: "#1b3478", coat: true, trim: "#e8c34a", buttons: "#f2f2f2", mustache: "#3a2a1a" },
  usCap: { straps: true, hat: "kepi", hatColor: "#1f3d8f", top: "#1f3d8f", coat: true, trim: "#e8c34a", buttons: "#e8c34a", sash: "#e8c34a", mustache: "#6a4a2a" },
  ukA: { straps: true, hat: "shako", hatColor: "#1b1b1b", top: "#c8202f", coat: true, trim: "#f2f2f2", buttons: "#e8c34a" },
  ukB: { straps: true, hat: "shako", hatColor: "#1b1b1b", top: "#b01c2a", coat: true, trim: "#e8c34a", buttons: "#f2f2f2", mustache: "#3a2a1a" },
  ukC: { straps: true, hat: "shako", hatColor: "#1b1b1b", top: "#d02a38", coat: true, trim: "#f2f2f2", buttons: "#e8c34a", hair: "#5a3a20", hairStyle: "side" },
  ukCap: { straps: true, hat: "shako", hatColor: "#1b1b1b", top: "#c8202f", coat: true, trim: "#f2f2f2", buttons: "#e8c34a", sash: "#f2f2f2", whiskers: "#6a4a2a" },
};
const texCache = new Map<string, THREE.CanvasTexture>();
export function charTex(who: string, e: Expr, p: PoseName, flip: boolean, blink = false, part: Part = "all") {
  const key = `${who}|${e}|${p}|${flip}|${blink}|${part}`;
  let t = texCache.get(key);
  if (!t) { t = toTex(who === "pig" ? paintPig(e === "shocked" ? "scared" : e === "worried" ? "dead" : "happy") : paintChar(LOOKS[who], e, p, flip, blink, part)); texCache.set(key, t); }
  return t;
}
const depthMats = new Map<THREE.Texture, THREE.MeshDepthMaterial>();
const depthFor = (t: THREE.Texture) => { let m = depthMats.get(t); if (!m) { m = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: t, alphaTest: 0.5 }); depthMats.set(t, m); } return m; };
export const yawTo = (p: V3, cam: CamPose) => Math.atan2(cam.pos.x - p[0], cam.pos.z - p[2]);
// hand position (right hand) in card-local metres for held props
export const handLocal = (pose: PoseName, flip: boolean, P: number): V3 => {
  const px: Record<string, [number, number]> = { hold: [430, 430], point: [520, 300], salute: [380, 120], up: [480, 150], idle: [395, 505], hip: [395, 470], cross: [270, 430] };
  const [x, y] = px[pose] ?? px.idle; const s = P / 1000;
  return [(flip ? -(x - 300) : x - 300) * s, (FEET - y) * s, 0.02];
};

export type Held = { kind: "musket" | "sign" | "scroll" | "note"; text?: string };
export type CastItem = { who: string; pos: V3; h?: number; expr: Expr; pose?: PoseName; flip?: boolean; to?: V3; walk?: [number, number]; bob?: number; held?: Held; tint?: string; dead?: boolean; rot?: number; vis?: [number, number] };

const HeldProp: React.FC<{ held: Held; hand: V3; P: number }> = ({ held, hand, P }) => {
  const sign = useMemo(() => (held.kind === "sign" || held.kind === "note" ? textTex(held.text ?? "", 256, 160, held.kind === "note" ? "#d8e8c0" : "#f6efe0", held.kind === "note" ? "#2d5a2d" : "#7a1d1d", "900 100px Arial Black, Impact, sans-serif", "#3a2a1a") : null), [held.text, held.kind]);
  const s = P / 2.1;
  if (held.kind === "musket") return (
    <group position={hand} rotation={[0, 0, -0.9]} scale={s}>
      <mesh position={[0, 0.55, 0]} castShadow><cylinderGeometry args={[0.03, 0.03, 1.5, 10]} /><meshStandardMaterial color="#2b2b2f" metalness={0.6} roughness={0.4} /></mesh>
      <mesh position={[0, -0.3, 0]} castShadow><boxGeometry args={[0.09, 0.55, 0.07]} /><meshStandardMaterial color="#7a4a22" roughness={0.7} /></mesh>
    </group>);
  if (held.kind === "scroll") return (
    <group position={hand} rotation={[0, 0, 1.2]} scale={s}>
      <mesh castShadow><cylinderGeometry args={[0.07, 0.07, 0.6, 14]} /><meshStandardMaterial color="#f3ead2" roughness={0.8} /></mesh>
      <mesh position={[0, 0, 0.07]}><sphereGeometry args={[0.06, 12, 8]} /><meshStandardMaterial color="#c8202f" /></mesh>
    </group>);
  return (
    <group position={[hand[0], hand[1], hand[2] + 0.02]} scale={s}>
      {held.kind === "sign" && <mesh position={[0, -0.35, -0.01]}><cylinderGeometry args={[0.02, 0.02, 0.9, 6]} /><meshStandardMaterial color="#6a4a22" /></mesh>}
      <mesh position={[0, 0.15, 0]} castShadow><planeGeometry args={[0.7, 0.44]} /><meshBasicMaterial map={sign!} side={THREE.DoubleSide} toneMapped={false} /></mesh>
    </group>);
};

const hash = (str: string) => { let h = 0; for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) | 0; return Math.abs(h % 1000) / 1000; };
export const Char: React.FC<{ item: CastItem; f: number; cam: CamPose; tint: string; groundY: number; kicks?: number[]; rim?: boolean; idx?: number }> = ({ item, f, cam, tint, groundY, kicks = [], rim = true, idx = 0 }) => {
  const flip = !!item.flip, pose = item.pose ?? "idle";
  const isPig = item.who === "pig";
  const ph = hash(item.who + idx) * 6.28;
  const blink = !isPig && ((f + Math.floor(ph * 17)) % 96) < 4;
  const hM = item.h ?? (isPig ? 0.9 : 1.8);
  let pos: V3 = item.pos; let moving = false;
  if (item.to && item.walk) {
    const t = smootherstep((f - item.walk[0]) / (item.walk[1] - item.walk[0]));
    pos = [lerp(item.pos[0], item.to[0], t), lerp(item.pos[1], item.to[1], t), lerp(item.pos[2], item.to[2], t)];
    moving = f > item.walk[0] && f < item.walk[1];
  }
  const bobY = (moving ? Math.abs(Math.sin(f * 0.55)) * 0.07 : (item.bob ?? 0) * Math.sin(f * 0.18)) * hM;
  const P = isPig ? hM / 0.84 : hM / ((FEET - TOP) / H);
  const cw = isPig ? P * (800 / 600) : P * (W / H);
  const yc = isPig ? P * 0.5 - P * 0.08 : P * 0.5 - (1 - FEET / H) * P;
  const yaw = yawTo(pos, cam);
  // squash & stretch: pop-in at the start of the shot, kick on impacts, breathing, walk stretch
  let imp = Math.exp(-f * 0.22) * Math.sin(f * 0.95) * 0.12;
  for (const k of kicks) { const d = f - k; if (d >= 0 && d < 24) imp -= Math.exp(-d * 0.2) * Math.sin(d * 0.9) * 0.07; }
  const breathe = Math.sin(f * 0.13 + ph) * 0.012;
  const sy = 1 + imp + breathe + (moving ? Math.abs(Math.sin(f * 0.55)) * 0.035 : 0), sx = 1 - imp * 0.7 - breathe * 0.5;
  const body = charTex(item.who, item.expr, pose, flip, blink, isPig ? "all" : "body");
  const dm = useMemo(() => depthFor(body), [body]);
  const hand = handLocal(pose, flip, P);
  const sc = P / 1000;
  const armLayer = (part: "armL" | "armR") => {
    const holdsProp = !!item.held && part === "armR";
    const sw = holdsProp ? 0 : moving ? Math.sin(f * 0.55) * 0.5 * (part === "armL" ? 1 : -1) : Math.sin(f * 0.11 + ph + (part === "armL" ? 0 : 1.6)) * (pose === "idle" ? 0.045 : 0.02);
    const [px, py] = SHOULDER[part]; const wx = (flip ? W - px : px) - 300;
    const pvx = wx * sc, pvy = (FEET - py) * sc + bobY;
    return (
      <group key={part} position={[pvx, pvy, 0.012]} rotation={[0, 0, sw]}>
        <mesh position={[-pvx, yc + bobY - pvy, 0]}>
          <planeGeometry args={[cw, P]} />
          <meshBasicMaterial map={charTex(item.who, item.expr, pose, flip, false, part)} transparent alphaTest={0.4} side={THREE.DoubleSide} color={item.tint ?? tint} toneMapped={false} />
        </mesh>
      </group>
    );
  };
  return (
    <group position={[pos[0], pos[1] + groundY, pos[2]]} rotation={[0, yaw, item.rot ?? 0]}>
      <group scale={[sx, sy, 1]}>
        {rim && (
          <mesh position={[0.014 * P, yc + bobY, -0.01]} scale={[1.018, 1.012, 1]}>
            <planeGeometry args={[cw, P]} /><meshBasicMaterial map={body} transparent alphaTest={0.4} side={THREE.DoubleSide} color="#ffb257" opacity={0.7} toneMapped={false} />
          </mesh>
        )}
        <mesh position={[0, yc + bobY, 0]} castShadow>
          <planeGeometry args={[cw, P]} />
          <meshBasicMaterial map={body} transparent alphaTest={0.4} side={THREE.DoubleSide} color={item.tint ?? tint} toneMapped={false} />
          <primitive object={dm} attach="customDepthMaterial" />
        </mesh>
        {!isPig && armLayer("armL")}
        {!isPig && armLayer("armR")}
        {item.held && <HeldProp held={item.held} hand={[hand[0], hand[1] + bobY, hand[2] + 0.03]} P={P} />}
      </group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.03, 0]} scale={[1, 0.5, 1]}><circleGeometry args={[hM * (isPig ? 0.7 : 0.4), 24]} /><meshBasicMaterial color="#000" transparent opacity={0.3} depthWrite={false} /></mesh>
    </group>
  );
};

export const Stone: React.FC<{ pos: V3; cam: CamPose; tint: string; groundY: number }> = ({ pos, cam, tint, groundY }) => {
  const tex = useMemo(() => toTex(paintStone()), []);
  const dm = useMemo(() => depthFor(tex), [tex]);
  return (
    <group position={[pos[0], pos[1] + groundY, pos[2]]} rotation={[0, yawTo(pos, cam), 0]}>
      <mesh position={[0, 0.5, 0]} castShadow><planeGeometry args={[0.8, 1.0]} /><meshBasicMaterial map={tex} transparent alphaTest={0.4} side={THREE.DoubleSide} color={tint} toneMapped={false} /><primitive object={dm} attach="customDepthMaterial" /></mesh>
    </group>
  );
};

export type CrowdSpec = { who: string[]; center: V3; size: [number, number]; n: number; h?: number; seed: number; marching?: boolean; rows?: boolean };
export const Crowd: React.FC<{ spec: CrowdSpec; f: number; cam: CamPose; tint: string; heightAt: (x: number, z: number) => number }> = ({ spec, f, cam, tint, heightAt }) => {
  const hM = spec.h ?? 1.7;
  const refs = useRef<(THREE.InstancedMesh | null)[]>([]);
  const blob = useRef<THREE.InstancedMesh>(null);
  const pts = useMemo(() => {
    const r = mulberry32(spec.seed); const out: { x: number; z: number; v: number; ph: number; flip: boolean; s: number }[] = [];
    for (let i = 0; i < spec.n; i++) {
      let x: number, z: number;
      if (spec.rows) { const cols = Math.ceil(Math.sqrt(spec.n * (spec.size[0] / spec.size[1]))); const rowsN = Math.ceil(spec.n / cols); x = spec.center[0] + ((i % cols) / Math.max(1, cols - 1) - 0.5) * spec.size[0] + (r() - 0.5) * 0.4; z = spec.center[2] + (Math.floor(i / cols) / Math.max(1, rowsN - 1) - 0.5) * spec.size[1] + (r() - 0.5) * 0.4; }
      else { x = spec.center[0] + (r() - 0.5) * spec.size[0]; z = spec.center[2] + (r() - 0.5) * spec.size[1]; }
      out.push({ x, z, v: Math.floor(r() * spec.who.length), ph: r() * 6.28, flip: r() < 0.5, s: 0.9 + r() * 0.2 });
    }
    return out;
  }, [spec]);
  const mats = useMemo(() => spec.who.map((w, vi) => ({ t0: charTex(w, "neutral", "idle", false, false, "all"), t1: charTex(w, "neutral", "idle", true, false, "all"), vi })), [spec]);
  const P = hM / ((FEET - TOP) / H);
  useLayoutEffect(() => {
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), s = new THREE.Vector3(), p = new THREE.Vector3();
    const counts = spec.who.map(() => 0);
    pts.forEach((pt, i) => {
      const mesh = refs.current[pt.v]; if (!mesh) return;
      const bob = spec.marching ? Math.abs(Math.sin(f * 0.45 + pt.ph)) * 0.06 : Math.sin(f * 0.1 + pt.ph) * 0.012;
      const x = pt.x + (spec.marching ? Math.sin(f * 0.02 + pt.ph) * 0.0 : 0), z = pt.z;
      const y = heightAt(x, z);
      e.set(0, Math.atan2(cam.pos.x - x, cam.pos.z - z), 0); q.setFromEuler(e);
      p.set(x, y + (P * 0.5 - (1 - FEET / H) * P) * pt.s + bob, z); s.set(pt.s * (pt.flip ? -1 : 1), pt.s, 1);
      m.compose(p, q, s); mesh.setMatrixAt(counts[pt.v]++, m);
      if (blob.current) { p.set(x, y + 0.03, z); q.setFromEuler(new THREE.Euler(-Math.PI / 2, 0, 0)); s.set(1, 0.5, 1); m.compose(p, q, s); blob.current.setMatrixAt(i, m); }
    });
    spec.who.forEach((_, vi) => { const mesh = refs.current[vi]; if (mesh) { mesh.count = counts[vi]; mesh.instanceMatrix.needsUpdate = true; } });
    if (blob.current) blob.current.instanceMatrix.needsUpdate = true;
  }, [f, cam, pts]);
  const per = spec.who.map((_, vi) => pts.filter((p) => p.v === vi).length);
  return (
    <>
      {mats.map((m, vi) => (
        <instancedMesh key={vi} ref={(el) => { refs.current[vi] = el; }} args={[undefined, undefined, Math.max(1, per[vi])]} frustumCulled={false}>
          <planeGeometry args={[P * (W / H), P]} />
          <meshBasicMaterial map={m.t0} transparent alphaTest={0.4} side={THREE.DoubleSide} color={tint} toneMapped={false} />
        </instancedMesh>
      ))}
      <instancedMesh ref={blob} args={[undefined, undefined, spec.n]} frustumCulled={false}>
        <circleGeometry args={[hM * 0.4, 12]} /><meshBasicMaterial color="#000" transparent opacity={0.28} depthWrite={false} />
      </instancedMesh>
    </>
  );
};
