import React, { useMemo } from "react";
import * as THREE from "three";
import type { V3, CamPose } from "./camera";
import { spriteTex } from "./paint";
import { clamp } from "./util";

export type FxItem = { kind: "puff" | "flash" | "spark"; pos: V3; t0: number; dur: number; size: number; rise?: number; color?: string };
export const Fx: React.FC<{ items: FxItem[]; f: number; cam: CamPose }> = ({ items, f, cam }) => {
  const tex = useMemo(() => ({ puff: spriteTex("puff"), flash: spriteTex("flash"), spark: spriteTex("spark") }), []);
  return (
    <>
      {items.map((it, i) => {
        const t = (f - it.t0) / it.dur; if (t < 0 || t > 1) return null;
        const grow = it.kind === "flash" ? 0.6 + t * 0.6 : 0.4 + 1.0 * (1 - (1 - t) * (1 - t));
        const op = it.kind === "puff" ? 0.95 * (1 - clamp((t - 0.35) / 0.65)) : 1 - t;
        const yaw = Math.atan2(cam.pos.x - it.pos[0], cam.pos.z - it.pos[2]);
        return (
          <mesh key={i} position={[it.pos[0], it.pos[1] + (it.rise ?? 0) * t, it.pos[2]]} rotation={[0, yaw, it.kind === "spark" ? t * 3 : 0]} scale={[it.size * grow, it.size * grow, 1]} renderOrder={5}>
            <planeGeometry args={[1, 1]} /><meshBasicMaterial map={tex[it.kind]} transparent opacity={op} depthWrite={false} toneMapped={false} color={it.color ?? "#ffffff"} />
          </mesh>
        );
      })}
    </>
  );
};
