import React, { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import type { V3, CamPose } from "./camera";

export type LightName = "day" | "golden" | "night";
type Preset = { top: string; mid: string; hor: string; fog: string; fogN: number; fogF: number; sun: V3; moon: V3; sunCol: string; sunI: number; hemiS: string; hemiG: string; hemiI: number; disc: number; tint: string };
export const PRE: Record<LightName, Preset> = {
  day: { top: "#134DB4", mid: "#1D67D6", hor: "#76AEE8", fog: "#76AEE8", fogN: 60, fogF: 520, sun: [0.45, 0.62, 0.45], moon: [0, 1, 0], sunCol: "#fff0d2", sunI: 2.6, hemiS: "#a8d0ff", hemiG: "#5f9d3c", hemiI: 0.8, disc: 0, tint: "#ffffff" },
  golden: { top: "#1b4fa0", mid: "#4f78c4", hor: "#f2b27a", fog: "#eeb184", fogN: 50, fogF: 420, sun: [0.85, 0.28, 0.4], moon: [0, 1, 0], sunCol: "#ffb066", sunI: 3.0, hemiS: "#9fb7e8", hemiG: "#6a8f3a", hemiI: 0.65, disc: 0, tint: "#ffe2c0" },
  night: { top: "#060c28", mid: "#0f1b4b", hor: "#2a3d86", fog: "#1a2866", fogN: 30, fogF: 320, sun: [-0.3, 0.7, 0.5], moon: [-0.35, 0.3, -0.85], sunCol: "#bcd0ff", sunI: 0.75, hemiS: "#3d56a8", hemiG: "#14204a", hemiI: 0.6, disc: 1, tint: "#9fb2f0" },
};
const vert = `varying vec3 vP; void main(){ vP=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`;
const frag = `
uniform vec3 top; uniform vec3 mid; uniform vec3 hor; uniform vec3 sunDir; uniform vec3 sunCol; uniform float disc;
varying vec3 vP;
void main(){
  vec3 d=normalize(vP); float h=clamp(d.y,0.0,1.0);
  vec3 c=mix(hor,mid,smoothstep(0.0,0.30,h)); c=mix(c,top,smoothstep(0.25,0.85,h));
  float s=max(dot(d,normalize(sunDir)),0.0);
  if(disc>0.5){ c+=vec3(0.55,0.65,1.0)*pow(s,60.0)*0.30; c=mix(c,vec3(1.6,1.6,1.7),smoothstep(0.9986,0.9991,s)); }
  else { c+=sunCol*pow(s,24.0)*0.35; c=mix(c,vec3(2.0,1.9,1.6),smoothstep(0.9993,0.9997,s)); }
  gl_FragColor=vec4(c,1.0);
}`;
export const Sky: React.FC<{ name: LightName; cam: CamPose }> = ({ name, cam }) => {
  const p = PRE[name];
  const mat = useMemo(() => new THREE.ShaderMaterial({
    vertexShader: vert, fragmentShader: frag, side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: { top: { value: new THREE.Color(p.top) }, mid: { value: new THREE.Color(p.mid) }, hor: { value: new THREE.Color(p.hor) }, sunDir: { value: new THREE.Vector3(...(p.disc ? p.moon : p.sun)) }, sunCol: { value: new THREE.Color(p.sunCol) }, disc: { value: p.disc } },
  }), [name]);
  return <mesh position={cam.pos.toArray()} renderOrder={-10} frustumCulled={false}><sphereGeometry args={[1200, 32, 16]} /><primitive object={mat} attach="material" /></mesh>;
};
export const Lights: React.FC<{ name: LightName; focus: V3; size: number; extra?: { pos: V3; color: string; intensity: number; dist: number }[] }> = ({ name, focus, size, extra = [] }) => {
  const p = PRE[name];
  const light = useRef<THREE.DirectionalLight>(null!);
  const target = useRef<THREE.Object3D>(null!);
  useLayoutEffect(() => { light.current.target = target.current; target.current.updateMatrixWorld(); }, []);
  const dir = new THREE.Vector3(...p.sun).normalize().multiplyScalar(120);
  return (
    <>
      <fog attach="fog" args={[p.fog, p.fogN, p.fogF]} />
      <hemisphereLight args={[p.hemiS, p.hemiG, p.hemiI]} />
      <object3D ref={target} position={focus} />
      <directionalLight ref={light} color={p.sunCol} intensity={p.sunI} position={[focus[0] + dir.x, focus[1] + dir.y, focus[2] + dir.z]} castShadow
        shadow-mapSize={[2048, 2048]} shadow-camera-left={-size} shadow-camera-right={size} shadow-camera-top={size} shadow-camera-bottom={-size} shadow-camera-near={1} shadow-camera-far={320}
        shadow-bias={-0.0004} shadow-normalBias={0.05} />
      {extra.map((e, i) => <pointLight key={i} position={e.pos} color={e.color} intensity={e.intensity} distance={e.dist} decay={1.6} />)}
    </>
  );
};
