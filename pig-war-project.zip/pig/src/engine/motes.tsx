import React, { useLayoutEffect, useMemo } from "react";
import * as THREE from "three";
import type { CamPose } from "./camera";
import { mkCanvas, toTex } from "./paint";
import { mulberry32 } from "./util";

// floating dust motes: soft additive dots drifting through the camera's view volume
export const Motes: React.FC<{ f: number; cam: CamPose; night?: boolean; n?: number }> = ({ f, cam, night = false, n = 70 }) => {
  const geo = useMemo(() => { const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(n * 3), 3)); return g; }, [n]);
  const seeds = useMemo(() => { const r = mulberry32(77); return Array.from({ length: n }, () => ({ a: r() * 6.28, d: 2.5 + r() * 13, y: r(), ph: r() * 6.28 })); }, [n]);
  const dot = useMemo(() => { const c = mkCanvas(64, 64), g = c.getContext("2d")!; const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, "rgba(255,255,255,1)"); gr.addColorStop(0.4, "rgba(255,255,255,0.45)"); gr.addColorStop(1, "rgba(255,255,255,0)"); g.fillStyle = gr; g.fillRect(0, 0, 64, 64); return toTex(c); }, []);
  useLayoutEffect(() => {
    const fwd = cam.tgt.clone().sub(cam.pos).normalize(), right = new THREE.Vector3().crossVectors(fwd, new THREE.Vector3(0, 1, 0)).normalize(), up = new THREE.Vector3().crossVectors(right, fwd).normalize();
    const pos = geo.attributes.position as THREE.BufferAttribute; const v = new THREE.Vector3();
    seeds.forEach((s, i) => {
      const x = Math.cos(s.a) * s.d * 0.42 + Math.sin(f * 0.02 + s.ph) * 0.35, y = (s.y - 0.4) * s.d * 0.9 + Math.sin(f * 0.035 + s.ph) * 0.18 + f * 0.004 * ((i % 3) - 1);
      v.copy(cam.pos).addScaledVector(fwd, s.d).addScaledVector(right, x).addScaledVector(up, y); pos.setXYZ(i, v.x, v.y, v.z);
    });
    pos.needsUpdate = true;
  }, [f, cam, seeds, geo]);
  return <points geometry={geo} frustumCulled={false} renderOrder={6}><pointsMaterial map={dot} size={0.09} sizeAttenuation transparent opacity={night ? 0.7 : 0.55} depthWrite={false} color={night ? "#cfe0ff" : "#ffdf9c"} toneMapped={false} fog={false} blending={THREE.AdditiveBlending} /></points>;
};
