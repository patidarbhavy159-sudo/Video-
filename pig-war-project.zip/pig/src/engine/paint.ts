import * as THREE from "three";
import { mulberry32 } from "./util";

export const mkCanvas = (w: number, h: number) => { const c = document.createElement("canvas"); c.width = w; c.height = h; return c; };
export const toTex = (c: HTMLCanvasElement, repeat?: [number, number]) => {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeat[0], repeat[1]); }
  return t;
};
// blob drawn 9 times so it wraps seamlessly
const wrapBlob = (g: CanvasRenderingContext2D, S: number, x: number, y: number, r: number, col: string) => {
  g.fillStyle = col;
  for (const ox of [-S, 0, S]) for (const oy of [-S, 0, S]) { g.beginPath(); g.arc(x + ox, y + oy, r, 0, 7); g.fill(); }
};
export function grassTex(repeat: [number, number] = [60, 60]) {
  const S = 512, c = mkCanvas(S, S), g = c.getContext("2d")!, r = mulberry32(11);
  g.fillStyle = "#4e9e2c"; g.fillRect(0, 0, S, S);
  for (let i = 0; i < 70; i++) wrapBlob(g, S, r() * S, r() * S, 30 + r() * 70, r() < 0.5 ? "rgba(120,190,60,0.16)" : "rgba(30,110,40,0.16)");
  for (let i = 0; i < 900; i++) {
    const x = r() * S, y = r() * S; g.strokeStyle = r() < 0.5 ? "rgba(150,215,80,0.5)" : "rgba(30,100,30,0.45)"; g.lineWidth = 1.5;
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + (r() - 0.5) * 6, y - 5 - r() * 9); g.stroke();
  }
  return toTex(c, repeat);
}
export function dirtTex(repeat: [number, number] = [12, 12]) {
  const S = 256, c = mkCanvas(S, S), g = c.getContext("2d")!, r = mulberry32(5);
  g.fillStyle = "#b5642c"; g.fillRect(0, 0, S, S);
  for (let i = 0; i < 60; i++) wrapBlob(g, S, r() * S, r() * S, 10 + r() * 34, r() < 0.5 ? "rgba(220,130,60,0.25)" : "rgba(110,50,20,0.25)");
  for (let i = 0; i < 300; i++) { g.fillStyle = "rgba(60,25,10,0.35)"; g.fillRect(r() * S, r() * S, 2, 2); }
  return toTex(c, repeat);
}
export function sandTex(repeat: [number, number] = [20, 20]) {
  const S = 256, c = mkCanvas(S, S), g = c.getContext("2d")!, r = mulberry32(3);
  g.fillStyle = "#e6cf95"; g.fillRect(0, 0, S, S);
  for (let i = 0; i < 40; i++) wrapBlob(g, S, r() * S, r() * S, 12 + r() * 40, r() < 0.5 ? "rgba(255,240,190,0.3)" : "rgba(190,150,90,0.25)");
  return toTex(c, repeat);
}
export function planksTex(repeat: [number, number] = [2, 2], base = "#b98a52") {
  const W = 256, H = 256, c = mkCanvas(W, H), g = c.getContext("2d")!, r = mulberry32(9);
  g.fillStyle = base; g.fillRect(0, 0, W, H);
  for (let i = 0; i < 8; i++) {
    g.fillStyle = `rgba(${r() < 0.5 ? "255,220,160" : "70,40,15"},${0.12 + r() * 0.12})`; g.fillRect(0, i * 32, W, 32);
    g.fillStyle = "rgba(50,25,8,0.55)"; g.fillRect(0, i * 32, W, 2.5);
  }
  for (let i = 0; i < 80; i++) { g.strokeStyle = "rgba(60,30,10,0.18)"; g.beginPath(); const y = r() * H; g.moveTo(r() * W, y); g.lineTo(r() * W, y + 1); g.stroke(); }
  return toTex(c, repeat);
}
export function logsTex(repeat: [number, number] = [3, 2]) {
  const W = 256, H = 256, c = mkCanvas(W, H), g = c.getContext("2d")!, r = mulberry32(4);
  g.fillStyle = "#8a5a30"; g.fillRect(0, 0, W, H);
  for (let i = 0; i < 6; i++) {
    const y = i * 43; const grd = g.createLinearGradient(0, y, 0, y + 43);
    grd.addColorStop(0, "#b07a45"); grd.addColorStop(0.5, "#9a6836"); grd.addColorStop(1, "#5e3a1b");
    g.fillStyle = grd; g.fillRect(0, y, W, 43);
    for (let k = 0; k < 14; k++) { g.strokeStyle = "rgba(50,25,8,0.25)"; g.beginPath(); const yy = y + 4 + r() * 35; g.moveTo(r() * W, yy); g.lineTo(r() * W, yy); g.stroke(); }
  }
  return toTex(c, repeat);
}
export function tilesTex(repeat: [number, number] = [10, 10], a = "#d8cdb6", b = "#a89c84") {
  const S = 256, c = mkCanvas(S, S), g = c.getContext("2d")!;
  for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) { g.fillStyle = (i + j) % 2 ? a : b; g.fillRect(i * 64, j * 64, 64, 64); }
  g.strokeStyle = "rgba(60,50,40,0.5)"; g.lineWidth = 2;
  for (let i = 0; i <= 4; i++) { g.beginPath(); g.moveTo(i * 64, 0); g.lineTo(i * 64, S); g.moveTo(0, i * 64); g.lineTo(S, i * 64); g.stroke(); }
  return toTex(c, repeat);
}
export function canvasClothTex(base = "#f2ecd8") {
  const S = 128, c = mkCanvas(S, S), g = c.getContext("2d")!, r = mulberry32(2);
  g.fillStyle = base; g.fillRect(0, 0, S, S);
  for (let i = 0; i < 200; i++) { g.fillStyle = "rgba(120,100,70,0.08)"; g.fillRect(r() * S, r() * S, 12, 1); }
  return toTex(c, [2, 2]);
}
export function textTex(text: string, w: number, h: number, bg: string, fg: string, font = "900 90px Arial Black, Impact, sans-serif", border?: string) {
  const c = mkCanvas(w, h), g = c.getContext("2d")!;
  g.fillStyle = bg; g.fillRect(0, 0, w, h);
  if (border) { g.strokeStyle = border; g.lineWidth = 14; g.strokeRect(7, 7, w - 14, h - 14); }
  g.fillStyle = fg; g.font = font; g.textAlign = "center"; g.textBaseline = "middle"; g.fillText(text, w / 2, h / 2 + 4);
  return toTex(c);
}
export function flagTex(kind: "us" | "uk") {
  const W = 512, H = 300, c = mkCanvas(W, H), g = c.getContext("2d")!;
  if (kind === "us") {
    for (let i = 0; i < 13; i++) { g.fillStyle = i % 2 ? "#ffffff" : "#c8202f"; g.fillRect(0, (i * H) / 13, W, H / 13 + 1); }
    g.fillStyle = "#2a3a8c"; g.fillRect(0, 0, W * 0.42, (H * 7) / 13);
    g.fillStyle = "#fff"; for (let r = 0; r < 4; r++) for (let q = 0; q < 5; q++) { g.beginPath(); g.arc(24 + q * 40 + (r % 2) * 0, 22 + r * 36, 5, 0, 7); g.fill(); }
  } else {
    g.fillStyle = "#1c2f7a"; g.fillRect(0, 0, W, H);
    g.strokeStyle = "#fff"; g.lineWidth = 56; g.beginPath(); g.moveTo(0, 0); g.lineTo(W, H); g.moveTo(W, 0); g.lineTo(0, H); g.stroke();
    g.strokeStyle = "#c8202f"; g.lineWidth = 20; g.beginPath(); g.moveTo(0, 0); g.lineTo(W, H); g.moveTo(W, 0); g.lineTo(0, H); g.stroke();
    g.strokeStyle = "#fff"; g.lineWidth = 96; g.beginPath(); g.moveTo(W / 2, 0); g.lineTo(W / 2, H); g.moveTo(0, H / 2); g.lineTo(W, H / 2); g.stroke();
    g.strokeStyle = "#c8202f"; g.lineWidth = 56; g.beginPath(); g.moveTo(W / 2, 0); g.lineTo(W / 2, H); g.moveTo(0, H / 2); g.lineTo(W, H / 2); g.stroke();
  }
  return toTex(c);
}
export function spriteTex(kind: "puff" | "flash" | "spark") {
  const S = 256, c = mkCanvas(S, S), g = c.getContext("2d")!;
  if (kind === "puff") {
    const r = mulberry32(8);
    for (let i = 0; i < 9; i++) { const a = r() * 6.28, d = r() * 50; g.fillStyle = i % 2 ? "#f4f4f4" : "#d6d6d6"; g.beginPath(); g.arc(128 + Math.cos(a) * d, 128 + Math.sin(a) * d, 48 + r() * 24, 0, 7); g.fill(); }
    g.strokeStyle = "rgba(0,0,0,0.0)";
  } else if (kind === "flash") {
    g.fillStyle = "#ff9a1c"; g.beginPath();
    for (let i = 0; i < 16; i++) { const a = (i / 16) * 6.283, rr = i % 2 ? 60 : 124; g.lineTo(128 + Math.cos(a) * rr, 128 + Math.sin(a) * rr); }
    g.closePath(); g.fill(); g.fillStyle = "#fff3a0"; g.beginPath(); g.arc(128, 128, 46, 0, 7); g.fill();
  } else {
    g.fillStyle = "#fff"; g.beginPath();
    for (let i = 0; i < 8; i++) { const a = (i / 8) * 6.283, rr = i % 2 ? 14 : 120; g.lineTo(128 + Math.cos(a) * rr, 128 + Math.sin(a) * rr); }
    g.closePath(); g.fill();
  }
  return toTex(c);
}
