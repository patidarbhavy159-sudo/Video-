import React, { useEffect, useMemo } from "react";
import { useThree, useFrame } from "@react-three/fiber";
import { EffectComposer, RenderPass, EffectPass, BloomEffect, DepthOfFieldEffect, ToneMappingEffect, ToneMappingMode, HueSaturationEffect, BrightnessContrastEffect } from "postprocessing";

// Hand-built composer: the stock @react-three/postprocessing wrapper rendered a blank frame under Remotion.
export const Post: React.FC<{ focus: number; range: number; bokeh: number; bloom?: number; bloomThreshold?: number; outH: number }> = ({ focus, range, bokeh, bloom = 0.35, bloomThreshold = 1.0, outH }) => {
  const { gl, scene, camera, size } = useThree();
  const k = outH / 1920;
  const dof = useMemo(() => new DepthOfFieldEffect(camera, { worldFocusDistance: focus, worldFocusRange: range, bokehScale: bokeh * k }), [camera]);
  const composer = useMemo(() => {
    const c = new EffectComposer(gl, { multisampling: 4 });
    c.addPass(new RenderPass(scene, camera));
    c.addPass(new EffectPass(camera, dof, new BloomEffect({ intensity: bloom, luminanceThreshold: bloomThreshold, mipmapBlur: true, radius: 0.7 })));
    c.addPass(new EffectPass(camera, new ToneMappingEffect({ mode: ToneMappingMode.NEUTRAL }), new HueSaturationEffect({ saturation: 0.18 }), new BrightnessContrastEffect({ contrast: 0.06 })));
    return c;
  }, [gl, scene, camera]);
  useEffect(() => { composer.setSize(size.width, size.height, false); }, [composer, size]);
  dof.cocMaterial.worldFocusDistance = focus; dof.cocMaterial.worldFocusRange = range; dof.bokehScale = bokeh * k;
  useFrame((_, dt) => { composer.render(dt); }, 1);
  return null;
};
