import { mkCanvas } from "./paint";

export type Expr = "neutral" | "grin" | "smirk" | "angry" | "shocked" | "scared" | "laugh" | "worried" | "glare" | "proud";
export type PoseName = "idle" | "hip" | "point" | "up" | "hold" | "salute" | "cross";
export type Hat = "cap" | "straw" | "tophat" | "kepi" | "shako" | "pickel" | "none";
export type Look = {
  hat: Hat; hatColor: string; hair?: string; hairStyle?: "side" | "none" | "bun";
  top: string; bib?: string; coat?: boolean; trim?: string; buttons?: string;
  text?: string; whiskers?: string; mustache?: string; sash?: string; straps?: boolean;
};
export const W = 600, H = 1000, FEET = 890, TOP = 29;
const INK = "#0a0a0a", LW = 14;

const path = (g: CanvasRenderingContext2D, pts: number[][], close = true) => { g.beginPath(); pts.forEach((p, i) => (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]))); if (close) g.closePath(); };
const fillStroke = (g: CanvasRenderingContext2D, fill: string | CanvasGradient, lw = LW) => { g.fillStyle = fill; g.fill(); g.lineWidth = lw; g.strokeStyle = INK; g.lineJoin = "round"; g.lineCap = "round"; g.stroke(); };
const lit = (g: CanvasRenderingContext2D, x0: number, x1: number, col: string) => {
  // soft gradient: light on the left, shadow on the right
  const grd = g.createLinearGradient(x0, 0, x1, 0);
  grd.addColorStop(0, shade(col, 1.18)); grd.addColorStop(0.55, col); grd.addColorStop(1, shade(col, 0.72));
  return grd;
};
export function shade(hex: string, k: number) {
  const n = parseInt(hex.slice(1), 16); const r = Math.min(255, ((n >> 16) & 255) * k), gg = Math.min(255, ((n >> 8) & 255) * k), b = Math.min(255, (n & 255) * k);
  return `rgb(${r | 0},${gg | 0},${b | 0})`;
}

function arm(g: CanvasRenderingContext2D, sx: number, sy: number, ex: number, ey: number, bend: number) {
  const mx = (sx + ex) / 2 + bend, my = (sy + ey) / 2;
  g.strokeStyle = INK; g.lineWidth = LW; g.lineCap = "round"; g.beginPath(); g.moveTo(sx, sy); g.quadraticCurveTo(mx, my, ex, ey); g.stroke();
  g.fillStyle = INK; g.beginPath(); g.arc(ex, ey, 17, 0, 7); g.fill();
}
function pose(g: CanvasRenderingContext2D, p: PoseName, side: "both" | "L" | "R" = "both") {
  const L = [235, 350], R = [365, 350];
  const aL = (...a: Parameters<typeof arm>) => { if (side !== "R") arm(...a); };
  const aR = (...a: Parameters<typeof arm>) => { if (side !== "L") arm(...a); };
  switch (p) {
    case "hip": aL(g, L[0], L[1], 205, 470, -40); aR(g, R[0], R[1], 395, 470, 40); break;
    case "point": aL(g, L[0], L[1], 190, 500, -10); aR(g, R[0], R[1], 520, 300, 10); break;
    case "up": aL(g, L[0], L[1], 120, 150, -30); aR(g, R[0], R[1], 480, 150, 30); break;
    case "hold": aL(g, L[0], L[1], 215, 500, -10); aR(g, R[0], R[1], 430, 430, 30); break;
    case "salute": aL(g, L[0], L[1], 215, 500, -10); aR(g, R[0], R[1], 380, 120, 60); break;
    case "cross": aL(g, L[0], L[1], 330, 430, 10); aR(g, R[0], R[1], 270, 430, -10); break;
    default: aL(g, L[0], L[1], 205, 505, -18); aR(g, R[0], R[1], 395, 505, 18);
  }
}
function legs(g: CanvasRenderingContext2D, look: Look) {
  g.strokeStyle = INK; g.lineWidth = LW; g.lineCap = "round";
  g.beginPath(); g.moveTo(272, 480); g.lineTo(255, FEET - 30); g.moveTo(328, 480); g.lineTo(345, FEET - 30); g.stroke();
  g.fillStyle = INK;
  for (const x of [250, 350]) { g.beginPath(); g.ellipse(x + (x < 300 ? -14 : 14), FEET - 14, 36, 16, 0, 0, 7); g.fill(); }
}
function torso(g: CanvasRenderingContext2D, look: Look) {
  if (look.coat) {
    path(g, [[225, 325], [375, 325], [400, 420], [410, 560], [190, 560], [200, 420]]);
    fillStroke(g, lit(g, 190, 410, look.top));
    if (look.trim) { path(g, [[285, 325], [315, 325], [318, 560], [282, 560]]); fillStroke(g, look.trim, 8); }
    g.fillStyle = look.buttons ?? "#f0c33c"; for (let i = 0; i < 4; i++) { g.beginPath(); g.arc(300, 360 + i * 48, 8, 0, 7); g.fill(); }
    if (look.sash) { path(g, [[222, 330], [250, 322], [395, 470], [365, 490]]); fillStroke(g, look.sash, 8); }
    if (look.straps) { g.lineCap = "round"; for (const [x0, x1] of [[245, 380], [355, 220]]) { g.strokeStyle = INK; g.lineWidth = 24; g.beginPath(); g.moveTo(x0, 330); g.lineTo(x1, 500); g.stroke(); g.strokeStyle = "#f4f1e6"; g.lineWidth = 13; g.beginPath(); g.moveTo(x0, 330); g.lineTo(x1, 500); g.stroke(); } }
    path(g, [[196, 498], [404, 498], [406, 524], [194, 524]]); fillStroke(g, "#2a1a10", 8);
    path(g, [[282, 494], [318, 494], [318, 528], [282, 528]]); fillStroke(g, "#e8c34a", 6);
    for (const x of [232, 368]) { g.beginPath(); g.ellipse(x, 331, 30, 13, x < 300 ? -0.25 : 0.25, 0, 7); fillStroke(g, look.trim ?? "#e8c34a", 6); }
  } else {
    path(g, [[228, 325], [372, 325], [395, 480], [205, 480]]);
    fillStroke(g, lit(g, 205, 395, look.top));
    if (look.bib) {
      path(g, [[250, 400], [350, 400], [352, 482], [248, 482]]); fillStroke(g, look.bib, 10);
      g.strokeStyle = INK; g.lineWidth = 10; g.beginPath(); g.moveTo(255, 400); g.lineTo(240, 330); g.moveTo(345, 400); g.lineTo(360, 330); g.stroke();
      g.strokeStyle = look.bib; g.lineWidth = 4; g.beginPath(); g.moveTo(255, 400); g.lineTo(240, 335); g.moveTo(345, 400); g.lineTo(360, 335); g.stroke();
      path(g, [[262, 326], [300, 360], [338, 326], [322, 322], [300, 340], [278, 322]]); fillStroke(g, "#fff3c2", 6);
      if (look.text) { g.fillStyle = "#c8202f"; g.fillRect(268, 415, 64, 34); g.strokeStyle = INK; g.lineWidth = 5; g.strokeRect(268, 415, 64, 34); g.fillStyle = "#fff"; g.font = "900 22px Arial Black, Arial"; g.textAlign = "center"; g.textBaseline = "middle"; g.fillText(look.text, 300, 433); }
    }
  }
  g.fillStyle = "rgba(0,0,0,0.14)"; g.fillRect(200, look.coat ? 470 : 440, 210, 40);
  // pale streak on the lit edge
  g.strokeStyle = "rgba(255,255,255,0.28)"; g.lineWidth = 8; g.beginPath(); g.moveTo(236, 345); g.lineTo(224, 460); g.stroke();
}
function face(g: CanvasRenderingContext2D, e: Expr, look: Look, blink = false) {
  const cx = 300, cy = 178; g.strokeStyle = INK; g.fillStyle = INK; g.lineCap = "round"; g.lineWidth = 11;
  const eye = (x: number, r = 12) => { if (blink) { g.lineWidth = 9; g.beginPath(); g.moveTo(x - 17, cy + 3); g.lineTo(x + 17, cy + 3); g.stroke(); g.lineWidth = 11; } else { g.beginPath(); g.arc(x, cy, r, 0, 7); g.fill(); } };
  const arc = (x: number) => { g.beginPath(); g.arc(x, cy + 6, 22, Math.PI * 1.1, Math.PI * 1.9); g.stroke(); };
  const brow = (x: number, dy1: number, dy2: number, dir: number) => { g.beginPath(); g.moveTo(x - 24 * dir, cy - 42 + dy1); g.lineTo(x + 24 * dir, cy - 42 + dy2); g.stroke(); };
  const bigEye = (x: number, pupil = 9) => { g.fillStyle = "#fff"; g.beginPath(); g.arc(x, cy - 2, 34, 0, 7); g.fill(); g.lineWidth = 9; g.stroke(); g.fillStyle = INK; g.beginPath(); g.arc(x + 3, cy, pupil, 0, 7); g.fill(); };
  switch (e) {
    case "grin": arc(250); arc(350); g.beginPath(); g.moveTo(246, cy + 50); g.quadraticCurveTo(300, cy + 112, 354, cy + 50); g.closePath(); g.fillStyle = "#fff"; g.fill(); g.stroke(); break;
    case "laugh": arc(250); arc(350); g.beginPath(); g.moveTo(240, cy + 46); g.quadraticCurveTo(300, cy + 130, 360, cy + 46); g.closePath(); g.fillStyle = "#7a1d1d"; g.fill(); g.stroke(); break;
    case "proud": arc(250); arc(350); g.beginPath(); g.moveTo(262, cy + 62); g.quadraticCurveTo(300, cy + 86, 338, cy + 62); g.stroke(); break;
    case "angry": eye(252, 11); eye(348, 11); brow(252, -6, 10, 1); brow(348, 10, -6, 1); g.beginPath(); g.moveTo(262, cy + 74); g.quadraticCurveTo(300, cy + 54, 338, cy + 74); g.stroke(); break;
    case "glare": eye(252, 10); eye(348, 10); g.lineWidth = 14; g.beginPath(); g.moveTo(222, cy - 6); g.lineTo(282, cy - 10); g.moveTo(318, cy - 10); g.lineTo(378, cy - 6); g.stroke(); g.lineWidth = 9; brow(252, -4, 12, 1); brow(348, 12, -4, 1); g.beginPath(); g.moveTo(268, cy + 68); g.lineTo(332, cy + 68); g.stroke(); break;
    case "shocked": bigEye(250); bigEye(350); g.beginPath(); g.ellipse(300, cy + 78, 20, 28, 0, 0, 7); g.fillStyle = "#7a1d1d"; g.fill(); g.lineWidth = 9; g.stroke(); break;
    case "scared": bigEye(250, 6); bigEye(350, 6); brow(250, 8, -10, 1); brow(350, -10, 8, 1); g.beginPath(); g.moveTo(262, cy + 78); g.lineTo(275, cy + 68); g.lineTo(290, cy + 80); g.lineTo(305, cy + 68); g.lineTo(320, cy + 80); g.lineTo(338, cy + 70); g.stroke(); break;
    case "worried": eye(252); eye(348); brow(252, 8, -8, 1); brow(348, -8, 8, 1); g.beginPath(); g.moveTo(266, cy + 72); g.quadraticCurveTo(300, cy + 56, 334, cy + 72); g.stroke(); break;
    case "smirk": eye(252); eye(348); brow(252, 0, 0, 1); brow(348, -14, -6, 1); g.beginPath(); g.moveTo(268, cy + 66); g.quadraticCurveTo(318, cy + 82, 346, cy + 54); g.stroke(); break;
    default: eye(252); eye(348); brow(252, 0, 0, 1); brow(348, 0, 0, 1); g.beginPath(); g.moveTo(272, cy + 68); g.lineTo(328, cy + 68); g.stroke();
  }
  if (look.mustache) { g.fillStyle = look.mustache; g.beginPath(); g.moveTo(300, cy + 48); g.quadraticCurveTo(250, cy + 30, 226, cy + 62); g.quadraticCurveTo(262, cy + 74, 300, cy + 56); g.quadraticCurveTo(338, cy + 74, 374, cy + 62); g.quadraticCurveTo(350, cy + 30, 300, cy + 48); g.fill(); g.lineWidth = 6; g.strokeStyle = INK; g.stroke(); }
}
function hair(g: CanvasRenderingContext2D, look: Look) {
  if (look.whiskers) { // mutton-chop side whiskers
    for (const s of [-1, 1]) { g.beginPath(); g.moveTo(300 + s * 128, 150); g.quadraticCurveTo(300 + s * 168, 230, 300 + s * 112, 290); g.quadraticCurveTo(300 + s * 128, 220, 300 + s * 118, 170); g.closePath(); fillStroke(g, look.whiskers, 8); }
  }
  if (look.hairStyle === "side" && look.hair) { g.beginPath(); g.moveTo(160, 160); g.quadraticCurveTo(170, 40, 300, 34); g.quadraticCurveTo(420, 40, 436, 150); g.quadraticCurveTo(330, 90, 160, 160); g.closePath(); fillStroke(g, look.hair, 10); }
}
function hat(g: CanvasRenderingContext2D, look: Look) {
  const c = look.hatColor;
  switch (look.hat) {
    case "cap": g.beginPath(); g.moveTo(158, 130); g.quadraticCurveTo(160, 20, 300, 18); g.quadraticCurveTo(440, 20, 442, 130); g.closePath(); fillStroke(g, lit(g, 158, 442, c)); path(g, [[160, 112], [440, 112], [442, 138], [158, 138]]); fillStroke(g, shade(c, 0.6), 9); g.beginPath(); g.moveTo(420, 128); g.quadraticCurveTo(520, 128, 548, 150); g.quadraticCurveTo(480, 156, 420, 142); g.closePath(); fillStroke(g, shade(c, 0.85), 10); break;
    case "straw": g.beginPath(); g.ellipse(300, 104, 215, 34, 0, 0, 7); fillStroke(g, "#e2c36a", 12); g.beginPath(); g.moveTo(190, 100); g.quadraticCurveTo(200, -6, 300, -6); g.quadraticCurveTo(400, -6, 410, 100); g.closePath(); fillStroke(g, lit(g, 190, 410, "#ecd078"), 12); path(g, [[192, 84], [408, 84], [410, 104], [190, 104]]); fillStroke(g, c, 8); break;
    case "tophat": g.beginPath(); g.ellipse(300, 98, 200, 30, 0, 0, 7); fillStroke(g, "#1b1b1b", 12); path(g, [[205, 98], [215, -50], [385, -50], [395, 98]]); fillStroke(g, lit(g, 205, 395, "#2a2a2a"), 12); path(g, [[207, 70], [393, 70], [395, 98], [205, 98]]); fillStroke(g, c, 8); break;
    case "kepi": path(g, [[170, 118], [190, 20], [400, 14], [430, 118]]); fillStroke(g, lit(g, 170, 430, c), 12); g.beginPath(); g.ellipse(420, 124, 120, 18, 0.05, 0, 7); fillStroke(g, "#151515", 10); g.fillStyle = "#f0c33c"; g.beginPath(); g.arc(300, 76, 14, 0, 7); g.fill(); break;
    case "shako": path(g, [[196, 112], [208, -70], [392, -70], [404, 112]]); fillStroke(g, lit(g, 196, 404, "#1b1b1b"), 12); g.fillStyle = "#f0c33c"; g.beginPath(); g.arc(300, 30, 18, 0, 7); g.fill(); g.lineWidth = 5; g.stroke(); g.fillStyle = "#fff"; g.beginPath(); g.arc(300, -84, 24, 0, 7); g.fill(); g.lineWidth = 7; g.stroke(); path(g, [[196, 100], [404, 100], [408, 124], [192, 124]]); fillStroke(g, "#151515", 8); break;
    case "pickel": g.beginPath(); g.moveTo(166, 126); g.quadraticCurveTo(170, -4, 300, -8); g.quadraticCurveTo(430, -4, 434, 126); g.closePath(); fillStroke(g, lit(g, 166, 434, "#d9dde6"), 12); path(g, [[286, -6], [314, -6], [306, -78], [294, -78]]); fillStroke(g, "#e8c34a", 8); path(g, [[166, 112], [434, 112], [440, 138], [160, 138]]); fillStroke(g, "#151515", 8); g.fillStyle = "#e8c34a"; g.beginPath(); g.moveTo(300, 40); g.lineTo(334, 100); g.lineTo(266, 100); g.closePath(); g.fill(); g.lineWidth = 6; g.stroke(); break;
    default: break;
  }
}
export type Part = "all" | "body" | "armL" | "armR";
export const SHOULDER: Record<"armL" | "armR", [number, number]> = { armL: [235, 350], armR: [365, 350] };
export function paintChar(look: Look, e: Expr, p: PoseName, flip = false, blink = false, part: Part = "all") {
  const c = mkCanvas(W, H), g = c.getContext("2d")!;
  if (flip) { g.translate(W, 0); g.scale(-1, 1); }
  if (part === "all" || part === "body") { legs(g, look); torso(g, look); }
  if (part === "all") pose(g, p); else if (part === "armL") pose(g, p, "L"); else if (part === "armR") pose(g, p, "R");
  if (part === "all" || part === "body") {
    g.beginPath(); g.ellipse(300, 170, 150, 141, 0, 0, 7); const hg = g.createLinearGradient(150, 0, 450, 0); hg.addColorStop(0, "#ffffff"); hg.addColorStop(0.7, "#f7f7f7"); hg.addColorStop(1, "#e6e6e6");
    fillStroke(g, hg);
    hair(g, look); face(g, e, look, blink); hat(g, look);
  }
  return c;
}
// ---- pig (card is 800x600) ----
export function paintPig(state: "happy" | "dead" | "scared") {
  const c = mkCanvas(800, 600), g = c.getContext("2d")!;
  if (state === "dead") { g.translate(0, 600); g.scale(1, -1); g.translate(0, -30); }
  const pink = "#f4a6b6", dark = "#e9849a";
  // legs
  for (const x of [250, 330, 470, 550]) { g.beginPath(); g.roundRect(x - 26, 430, 52, 110, 14); fillStroke(g, lit(g, x - 26, x + 26, pink), 12); g.fillStyle = "#6b3a45"; g.fillRect(x - 24, 520, 48, 18); }
  // tail
  g.strokeStyle = INK; g.lineWidth = 14; g.lineCap = "round"; g.beginPath(); g.moveTo(150, 330); g.bezierCurveTo(70, 330, 70, 240, 130, 250); g.bezierCurveTo(165, 255, 150, 295, 125, 285); g.stroke();
  // body
  g.beginPath(); g.ellipse(390, 330, 262, 175, 0, 0, 7); fillStroke(g, lit(g, 130, 650, pink));
  g.strokeStyle = "rgba(255,255,255,0.3)"; g.lineWidth = 10; g.beginPath(); g.moveTo(250, 215); g.quadraticCurveTo(360, 170, 470, 190); g.stroke();
  // head
  g.beginPath(); g.ellipse(640, 300, 128, 118, 0, 0, 7); fillStroke(g, lit(g, 520, 770, pink));
  // ear
  g.beginPath(); g.moveTo(580, 210); g.lineTo(600, 100); g.lineTo(680, 190); g.closePath(); fillStroke(g, dark, 12);
  // snout
  g.beginPath(); g.ellipse(738, 322, 52, 44, 0, 0, 7); fillStroke(g, dark, 12); g.fillStyle = INK; g.beginPath(); g.ellipse(728, 322, 7, 12, 0, 0, 7); g.ellipse(752, 322, 7, 12, 0, 0, 7); g.fill();
  // eye
  g.strokeStyle = INK; g.fillStyle = INK; g.lineWidth = 10;
  if (state === "dead") { g.beginPath(); g.moveTo(640, 250); g.lineTo(676, 286); g.moveTo(676, 250); g.lineTo(640, 286); g.stroke(); }
  else if (state === "scared") { g.fillStyle = "#fff"; g.beginPath(); g.arc(662, 268, 28, 0, 7); g.fill(); g.lineWidth = 8; g.stroke(); g.fillStyle = INK; g.beginPath(); g.arc(666, 270, 7, 0, 7); g.fill(); }
  else { g.beginPath(); g.arc(660, 268, 13, 0, 7); g.fill(); g.lineWidth = 8; g.beginPath(); g.moveTo(640, 236); g.lineTo(686, 244); g.stroke(); }
  if (state === "happy") { g.lineWidth = 9; g.beginPath(); g.moveTo(690, 372); g.quadraticCurveTo(730, 392, 760, 366); g.stroke(); }
  if (state === "dead") { g.fillStyle = "#e85d75"; g.beginPath(); g.ellipse(718, 384, 16, 24, 0, 0, 7); g.fill(); g.lineWidth = 7; g.stroke(); }
  return c;
}
export function paintStone() {
  const c = mkCanvas(400, 500), g = c.getContext("2d")!;
  g.beginPath(); g.moveTo(60, 480); g.lineTo(60, 200); g.quadraticCurveTo(60, 40, 200, 40); g.quadraticCurveTo(340, 40, 340, 200); g.lineTo(340, 480); g.closePath();
  fillStroke(g, lit(g, 60, 340, "#b9bcc4"), 14);
  g.fillStyle = "#3b3d44"; g.font = "900 96px Arial Black, Impact, sans-serif"; g.textAlign = "center"; g.fillText("PIG", 200, 230);
  g.font = "900 54px Arial Black, Impact, sans-serif"; g.fillText("1859", 200, 310);
  g.strokeStyle = "#3b3d44"; g.lineWidth = 8; g.beginPath(); g.moveTo(130, 350); g.lineTo(270, 350); g.stroke();
  return c;
}
