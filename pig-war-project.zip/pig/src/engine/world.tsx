import React, { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { makeNoise, fbm, smoothstep, lerp, mulberry32 } from "./util";
import { grassTex, sandTex, dirtTex, mkCanvas, toTex } from "./paint";
import type { LightName } from "./lights";

export type Loc = "island" | "meadow" | "farm" | "beach" | "sea" | "camp" | "hall" | "hill";
const N = makeNoise(7), N2 = makeNoise(21);
const bump = (x: number, z: number, cx: number, cz: number, r: number, h: number) => h * Math.exp(-(((x - cx) ** 2 + (z - cz) ** 2) / (r * r)));
const hills = (x: number, z: number, k = 1) => fbm(N, x * 0.012, z * 0.012, 3) * 16 * k + fbm(N2, x * 0.04, z * 0.04, 2) * 2.5 * k;

export const heightFn = (loc: Loc) => (x: number, z: number): number => {
  switch (loc) {
    case "island": case "camp": {
      const r = Math.hypot(x, z * 0.85); const m = 1 - smoothstep(60, 95, r);
      let h = m * (4 + 7 * fbm(N, x * 0.025, z * 0.025, 3)) - (1 - m) * 7;
      h += bump(x, z, 300, -320, 110, 16) + bump(x, z, -330, -260, 90, 11) + bump(x, z, 380, -60, 80, 13) + bump(x, z, -280, 200, 70, 9) + bump(x, z, 120, -520, 160, 20);
      return h;
    }
    case "sea": return -6 + bump(x, z, 0, -330, 130, 24) + bump(x, z, -380, -200, 100, 14) + bump(x, z, 400, -260, 120, 16) + bump(x, z, 500, 100, 90, 10);
    case "beach": {
      const s = smoothstep(2, -9, z); let h = lerp(-1.8, 0.45, s);
      h += s * smoothstep(-14, -70, z) * (hills(x, z, 0.9) + 2);
      return h;
    }
    case "hall": return 0;
    default: { // meadow, farm, hill: flat middle, rolling hills beyond
      const r = Math.hypot(x, z); const rise = smoothstep(40, 130, r);
      return 0.3 * fbm(N2, x * 0.05, z * 0.05, 2) + rise * (hills(x, z) + 6) + (loc === "hill" ? bump(x, z, 0, 0, 6, 0.5) : 0);
    }
  }
};

const splatMat = (tint: string) => {
  const g = grassTex([1, 1]); g.repeat.set(1, 1);
  const sand = sandTex([1, 1]), dirt = dirtTex([1, 1]);
  const m = new THREE.MeshStandardMaterial({ map: g, roughness: 0.95, metalness: 0, vertexColors: true, color: new THREE.Color(tint) });
  m.onBeforeCompile = (sh) => {
    sh.uniforms.sandMap = { value: sand }; sh.uniforms.dirtMap = { value: dirt };
    sh.vertexShader = sh.vertexShader.replace("#include <common>", "#include <common>\nattribute vec2 aSplat; varying vec2 vSplat; varying vec2 vWorldUv;").replace("#include <begin_vertex>", "#include <begin_vertex>\nvSplat=aSplat; vWorldUv=position.xz;");
    sh.fragmentShader = sh.fragmentShader.replace("#include <common>", "#include <common>\nuniform sampler2D sandMap; uniform sampler2D dirtMap; varying vec2 vSplat; varying vec2 vWorldUv;")
      .replace("#include <map_fragment>", `vec4 gc = texture2D(map, vWorldUv*0.11); vec4 sc = texture2D(sandMap, vWorldUv*0.07); vec4 dc = texture2D(dirtMap, vWorldUv*0.09);
        vec4 sampledDiffuseColor = mix(mix(gc, dc, vSplat.y), sc, vSplat.x); diffuseColor *= sampledDiffuseColor;`);
  };
  return m;
};
const buildTerrain = (loc: Loc, size: number, seg: number, drop: number, tint: string, dirtAt?: (x: number, z: number) => number) => {
  const geo = new THREE.PlaneGeometry(size, size, seg, seg); geo.rotateX(-Math.PI / 2);
  const hf = heightFn(loc); const pos = geo.attributes.position as THREE.BufferAttribute;
  const col = new Float32Array(pos.count * 3), splat = new Float32Array(pos.count * 2);
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i), h = hf(x, z); pos.setY(i, h - drop);
    const v = 0.82 + 0.3 * fbm(N2, x * 0.03, z * 0.03, 2) + 0.12 * (fbm(N, x * 0.2, z * 0.2, 1) - 0.5);
    col[i * 3] = v; col[i * 3 + 1] = v; col[i * 3 + 2] = v * 0.97;
    const shore = loc === "beach" || loc === "island" || loc === "camp" || loc === "sea";
    splat[i * 2] = shore ? 1 - smoothstep(0.3, 1.0, h) : 0;
    splat[i * 2 + 1] = dirtAt ? dirtAt(x, z) : smoothstep(0.62, 0.78, fbm(N, x * 0.035 + 9, z * 0.035, 2)) * 0.9;
  }
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3)); geo.setAttribute("aSplat", new THREE.BufferAttribute(splat, 2));
  geo.computeVertexNormals();
  const mesh = new THREE.Mesh(geo, splatMat(tint)); mesh.receiveShadow = true; mesh.castShadow = false;
  return mesh;
};
export const Terrain: React.FC<{ loc: Loc; light: LightName; dirtAt?: (x: number, z: number) => number }> = ({ loc, light, dirtAt }) => {
  const tint = light === "night" ? "#7f94d8" : light === "golden" ? "#ffe0b8" : "#ffffff";
  const near = useMemo(() => buildTerrain(loc, 260, 220, 0, tint, dirtAt), [loc, tint]);
  const far = useMemo(() => buildTerrain(loc, 2600, 130, 1.0, tint, dirtAt), [loc, tint]);
  if (loc === "hall") return null;
  return <><primitive object={near} /><primitive object={far} /></>;
};

export const Water: React.FC<{ light: LightName; f: number }> = ({ light, f }) => {
  const tex = useMemo(() => {
    const S = 512, c = mkCanvas(S, S), g = c.getContext("2d")!, r = mulberry32(31);
    g.fillStyle = "#2c8fc2"; g.fillRect(0, 0, S, S);
    for (let i = 0; i < 160; i++) { const x = r() * S, y = r() * S; g.strokeStyle = r() < 0.5 ? "rgba(255,255,255,0.28)" : "rgba(10,70,120,0.25)"; g.lineWidth = 3; g.beginPath(); g.ellipse(x, y, 20 + r() * 30, 3 + r() * 4, 0, 0, Math.PI); g.stroke(); }
    return toTex(c, [260, 260]);
  }, []);
  tex.offset.set(f * 0.0006, f * 0.0003);
  const color = light === "night" ? "#6e86d8" : light === "golden" ? "#ffd8b0" : "#ffffff";
  return <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow><planeGeometry args={[2800, 2800]} /><meshStandardMaterial map={tex} color={color} roughness={0.22} metalness={0.05} /></mesh>;
};

export const Clouds: React.FC<{ light: LightName; seed?: number; f?: number; speed?: number; lift?: number }> = ({ light, seed = 3, f = 0, speed = 0.06, lift = 0 }) => {
  const mesh = useRef<THREE.InstancedMesh>(null!);
  useLayoutEffect(() => {
    const r = mulberry32(seed), m = new THREE.Matrix4(); let k = 0;
    for (let c = 0; c < 14; c++) {
      const cx = (r() - 0.5) * 900, cz = -150 - r() * 600, cy = 90 + r() * 90, sc = 22 + r() * 24;
      for (let j = 0; j < 6; j++) { m.compose(new THREE.Vector3(cx + (j - 2.5) * sc * 0.7, cy + Math.sin(j * 1.7) * sc * 0.15, cz + (r() - 0.5) * sc), new THREE.Quaternion(), new THREE.Vector3(sc * (0.8 + r() * 0.5), sc * 0.34, sc * 0.7)); mesh.current.setMatrixAt(k++, m); }
    }
    mesh.current.instanceMatrix.needsUpdate = true;
  }, [seed]);
  const color = light === "night" ? "#7184c4" : light === "golden" ? "#ffd9b8" : "#ffffff";
  return <group position={[f * speed, lift, 0]}><instancedMesh ref={mesh} args={[undefined, undefined, 84]} frustumCulled={false}><icosahedronGeometry args={[1, 2]} /><meshBasicMaterial color={color} fog={false} transparent opacity={light === "night" ? 0.55 : 0.96} /></instancedMesh></group>;
};

const coneGeo = (rad: number, h: number, y: number, col: string) => { const g = new THREE.ConeGeometry(rad, h, 9, 1); g.translate(0, y, 0); return paintGeo(g, col); };
const paintGeo = (g: THREE.BufferGeometry, col: string) => { const c = new THREE.Color(col); const a = new Float32Array(g.attributes.position.count * 3); for (let i = 0; i < a.length; i += 3) { a[i] = c.r; a[i + 1] = c.g; a[i + 2] = c.b; } g.setAttribute("color", new THREE.BufferAttribute(a, 3)); return g; };
const mkConifer = () => { const t = new THREE.CylinderGeometry(0.28, 0.4, 2.2, 7); t.translate(0, 1.1, 0); return mergeGeometries([paintGeo(t, "#5a3a1e"), coneGeo(2.3, 3.4, 3.6, "#2e7a34"), coneGeo(1.8, 3.0, 5.4, "#368a3a"), coneGeo(1.2, 2.6, 7.0, "#3f9a40")].map((g) => g.index ? g.toNonIndexed() : g))!; };
const mkRound = () => { const t = new THREE.CylinderGeometry(0.3, 0.45, 2.6, 7); t.translate(0, 1.3, 0); const s = (x: number, y: number, z: number, r: number, c: string) => { const g = new THREE.IcosahedronGeometry(r, 1); g.translate(x, y, z); return paintGeo(g, c); }; return mergeGeometries([paintGeo(t, "#6a4524"), s(0, 4.0, 0, 2.3, "#3f9a3a"), s(1.3, 3.4, 0.5, 1.7, "#4aa843"), s(-1.2, 3.6, -0.6, 1.6, "#358c35")].map((g) => g.index ? g.toNonIndexed() : g))!; };

export const Trees: React.FC<{ loc: Loc; n: number; seed: number; avoid?: { x: number; z: number; r: number }[]; area?: number; minDist?: number; round?: number; light: LightName }> = ({ loc, n, seed, avoid = [], area = 130, minDist = 0, round = 0.2, light }) => {
  const con = useRef<THREE.InstancedMesh>(null!), rnd = useRef<THREE.InstancedMesh>(null!);
  const geos = useMemo(() => ({ c: mkConifer(), r: mkRound() }), []);
  const hf = useMemo(() => heightFn(loc), [loc]);
  useLayoutEffect(() => {
    const r = mulberry32(seed), m = new THREE.Matrix4(); let kc = 0, kr = 0; const col = new THREE.Color();
    for (let i = 0; i < n * 3 && kc + kr < n; i++) {
      const x = (r() - 0.5) * 2 * area, z = (r() - 0.5) * 2 * area;
      if (Math.hypot(x, z) < minDist) continue; if (avoid.some((a) => Math.hypot(x - a.x, z - a.z) < a.r)) continue;
      const h = hf(x, z); if (h < 0.9) continue;
      const sc = 0.8 + r() * 0.9, isR = r() < round;
      m.compose(new THREE.Vector3(x, h - 0.1, z), new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), r() * 6.28), new THREE.Vector3(sc, sc * (0.9 + r() * 0.3), sc));
      col.setHSL(0.3 + (r() - 0.5) * 0.04, 0.2 + r() * 0.1, 0.62 + r() * 0.35);
      if (isR) { rnd.current.setMatrixAt(kr, m); rnd.current.setColorAt(kr++, col); } else { con.current.setMatrixAt(kc, m); con.current.setColorAt(kc++, col); }
    }
    con.current.count = kc; rnd.current.count = kr;
    for (const mm of [con.current, rnd.current]) { mm.instanceMatrix.needsUpdate = true; if (mm.instanceColor) mm.instanceColor.needsUpdate = true; }
  }, [n, seed, loc]);
  const tint = light === "night" ? "#8095d8" : light === "golden" ? "#ffe0b8" : "#ffffff";
  return (
    <>
      <instancedMesh ref={con} args={[geos.c, undefined, n]} castShadow receiveShadow frustumCulled={false}><meshStandardMaterial vertexColors roughness={0.85} color={tint} /></instancedMesh>
      <instancedMesh ref={rnd} args={[geos.r, undefined, n]} castShadow receiveShadow frustumCulled={false}><meshStandardMaterial vertexColors roughness={0.85} color={tint} /></instancedMesh>
    </>
  );
};

// ---- dense grass blades (foreground depth + parallax, like the reference) ----
const bladeGeo = (() => {
  const w = 0.045, h = 1;
  const pos = [-w, 0, 0, w, 0, 0, -w * 0.6, h * 0.5, 0, w * 0.6, h * 0.5, 0, 0, h, 0];
  const col = [0.10, 0.30, 0.08, 0.10, 0.30, 0.08, 0.34, 0.70, 0.18, 0.34, 0.70, 0.18, 0.80, 0.96, 0.36];
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute("color", new THREE.Float32BufferAttribute(col, 3));
  g.setIndex([0, 1, 3, 0, 3, 2, 2, 3, 4]); g.computeVertexNormals(); return g;
})();
export const Grass: React.FC<{ loc: Loc; cx: number; cz: number; radius: number; n: number; seed: number; light: LightName; skip?: (x: number, z: number) => boolean }> = ({ loc, cx, cz, radius, n, seed, light, skip }) => {
  const mesh = useRef<THREE.InstancedMesh>(null!);
  const hf = useMemo(() => heightFn(loc), [loc]);
  useLayoutEffect(() => {
    const r = mulberry32(seed), m = new THREE.Matrix4(), col = new THREE.Color(); let k = 0;
    for (let i = 0; i < n * 2 && k < n; i++) {
      const a = r() * 6.283, d = radius * Math.sqrt(r()), x = cx + Math.cos(a) * d, z = cz + Math.sin(a) * d;
      const h = hf(x, z); if (h < (loc === "beach" ? 0.75 : -5) || (skip && skip(x, z))) continue;
      const sc = 0.3 + r() * 0.3 + (r() < 0.05 ? 0.2 : 0);
      m.compose(new THREE.Vector3(x, h - 0.02, z), new THREE.Quaternion().setFromEuler(new THREE.Euler((r() - 0.5) * 0.22, r() * 6.283, 0)), new THREE.Vector3(1.2 + r() * 0.8, sc, 1));
      mesh.current.setMatrixAt(k, m); col.setHSL(0.25 + (r() - 0.5) * 0.06, 0.45 + r() * 0.3, 0.72 + r() * 0.26); mesh.current.setColorAt(k++, col);
    }
    mesh.current.count = k; mesh.current.instanceMatrix.needsUpdate = true; if (mesh.current.instanceColor) mesh.current.instanceColor.needsUpdate = true;
  }, [loc, cx, cz, radius, n, seed]);
  const tint = light === "night" ? "#7f94d8" : light === "golden" ? "#ffe0b8" : "#ffffff";
  return <instancedMesh ref={mesh} args={[bladeGeo, undefined, n]} frustumCulled={false}><meshStandardMaterial vertexColors side={THREE.DoubleSide} roughness={0.9} color={tint} /></instancedMesh>;
};

// ---- sun shafts: soft additive beams along the light direction ----
import type { V3, CamPose } from "./camera";
import { PRE } from "./lights";
export const Shafts: React.FC<{ f: number; cam: CamPose; light: LightName; focus: V3 }> = ({ f, cam, light, focus }) => {
  const tex = useMemo(() => {
    const c = mkCanvas(64, 256), g = c.getContext("2d")!;
    const gx = g.createLinearGradient(0, 0, 64, 0); gx.addColorStop(0, "rgba(255,255,255,0)"); gx.addColorStop(0.5, "rgba(255,255,255,1)"); gx.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = gx; g.fillRect(0, 0, 64, 256);
    g.globalCompositeOperation = "destination-in"; const gy = g.createLinearGradient(0, 0, 0, 256); gy.addColorStop(0, "rgba(0,0,0,0)"); gy.addColorStop(0.25, "rgba(0,0,0,1)"); gy.addColorStop(0.8, "rgba(0,0,0,1)"); gy.addColorStop(1, "rgba(0,0,0,0)"); g.fillStyle = gy; g.fillRect(0, 0, 64, 256);
    return toTex(c);
  }, []);
  if (light === "night") return null;
  const pre = PRE[light]; const sun = new THREE.Vector3(...pre.sun).normalize();
  const beams = [0, 1, 2, 3, 4, 5, 6].map((i) => {
    const base = new THREE.Vector3(focus[0] + (i - 3) * 2.3 + Math.sin(i * 7.1) * 0.8, 0, focus[2] - 4 - (i % 3) * 3.5);
    const mid = base.clone().addScaledVector(sun, 18);
    const y = sun.clone(); const zA = cam.pos.clone().sub(mid); zA.addScaledVector(y, -zA.dot(y)).normalize(); const x = new THREE.Vector3().crossVectors(y, zA).normalize();
    const mat = new THREE.Matrix4().makeBasis(x, y, zA); const q = new THREE.Quaternion().setFromRotationMatrix(mat);
    return { mid, q, op: 0.10 + 0.05 * Math.sin(f * 0.025 + i * 1.9), w: 1.6 + (i % 3) * 0.9 };
  });
  return (
    <>{beams.map((b, i) => (
      <mesh key={i} position={b.mid} quaternion={b.q} renderOrder={4}>
        <planeGeometry args={[b.w, 36]} /><meshBasicMaterial map={tex} transparent opacity={b.op} depthWrite={false} blending={THREE.AdditiveBlending} color={pre.sunCol} fog={false} toneMapped={false} side={THREE.DoubleSide} />
      </mesh>))}</>
  );
};
