import React from "react";
import type { Key, V3 } from "../engine/camera";
import type { LightName } from "../engine/lights";
import type { Loc } from "../engine/world";
import type { CastItem, CrowdSpec } from "../engine/cast";
import type { FxItem } from "../engine/fx";
import { Flag, Tent, Cannon, Campfire, Rowboat, Ship, Cabin, RailFence, Potatoes } from "../engine/build";
import { heightFn } from "../engine/world";
import { smoothstep } from "../engine/util";

export type ShotSpec = {
  id: string; start: number; len: number; loc: Loc; light: LightName; focus: V3; shadow: number;
  cam: Key[]; kicks?: number[]; dof: { f0: number; f1: number; range: number; bokeh: number };
  cast: CastItem[]; crowds?: CrowdSpec[]; fx?: FxItem[]; flash?: { f: number; len: number }[];
  trees?: { n: number; seed: number; area: number; minDist: number; round?: number }; extraLights?: { pos: V3; color: string; intensity: number; dist: number }[];
  scene?: (f: number, hf: (x: number, z: number) => number) => React.ReactNode;
};
const FARM_FIELD = { c: [4, -11] as [number, number], s: [9, 8] as [number, number] };
export const farmDirt = (x: number, z: number) => {
  const dx = Math.abs(x - FARM_FIELD.c[0]) - FARM_FIELD.s[0] / 2, dz = Math.abs(z - FARM_FIELD.c[1]) - FARM_FIELD.s[1] / 2;
  const field = 1 - smoothstep(0, 2.2, Math.max(dx, dz));
  const path = (1 - smoothstep(0.8, 2.0, Math.abs(x + 3 - (z + 22) * 0.35))) * (z > -24 && z < -6 ? 1 : 0);
  return Math.max(field, path * 0.8);
};
const farmScene = (f: number, hf: (x: number, z: number) => number) => (
  <>
    <Cabin pos={[-5, hf(-5, -21), -21]} rot={0.2} />
    <Potatoes center={[FARM_FIELD.c[0], hf(4, -11), FARM_FIELD.c[1]]} size={FARM_FIELD.s} rows={9} hf={hf} />
    <RailFence a={[-8, 0, -14]} b={[-1, 0, -12]} hf={hf} /><RailFence a={[-1, 0, -12]} b={[-0.5, 0, -5]} hf={hf} />
    <RailFence a={[9, 0, -15]} b={[9.5, 0, -5]} hf={hf} /><RailFence a={[9.5, 0, -5]} b={[14, 0, -4]} hf={hf} />
  </>
);
// ~25 shots (avg ~1.3 s) with soft dissolves, timed to the voice-over pause map
const FT = { n: 380, seed: 12, area: 170, minDist: 45 };
const D = (f0: number, f1: number, range: number, bokeh: number) => ({ f0, f1, range, bokeh });
const flagsScene = (f: number, hf: (x: number, z: number) => number) => (<><Flag pos={[-4.4, hf(-4.4, -19), -19]} kind="us" f={f} h={7.5} /><Flag pos={[4.4, hf(4.4, -19), -19]} kind="uk" f={f} h={7.5} /><Tent pos={[-9, hf(-9, -23), -23]} kind="us" rot={0.4} /><Tent pos={[9, hf(9, -23), -23]} kind="uk" /></>);
const flagsCast: CastItem[] = [{ who: "usA", pos: [-3.2, 0, -13], expr: "glare" }, { who: "ukA", pos: [3.2, 0, -13], expr: "glare" }, { who: "usB", pos: [-4.6, 0, -16], expr: "glare" }, { who: "ukB", pos: [4.6, 0, -16], expr: "glare" }];
const ownerCast: CastItem[] = [{ who: "griffin", pos: [1.25, 0, -3], expr: "angry", pose: "up", h: 1.85, held: { kind: "sign", text: "$100" } }, { who: "mac", pos: [-1.2, 0, -3.2], expr: "worried", h: 1.8 }, { who: "pig", pos: [0, 0, -6.5], expr: "worried", h: 0.95 }];
const tenCast: CastItem[] = [{ who: "mac", pos: [-0.6, 0, -2], expr: "smirk", pose: "hold", h: 1.85, held: { kind: "note", text: "$10" } }, { who: "griffin", pos: [1.5, 0, -3.4], expr: "angry", pose: "cross", h: 1.85, flip: true }];
const boats = (f: number) => (<><Rowboat pos={[-3.2, 0, 0.5]} rot={Math.PI / 2} f={f} /><Rowboat pos={[1.2, 0, 1.5]} rot={Math.PI / 2 + 0.1} f={f} /><Rowboat pos={[4.6, 0, -0.5]} rot={Math.PI / 2 - 0.1} f={f} /></>);
const ships = (f: number) => (<><Ship pos={[-16, 0, -38]} rot={-0.35} f={f} s={1.1} /><Ship pos={[4, 0, -62]} rot={0.15} f={f + 20} /><Ship pos={[22, 0, -46]} rot={0.55} f={f + 40} s={1.05} /></>);
const usCrowd: CrowdSpec = { who: ["usA", "usB", "usC"], center: [-12, 0, -4], size: [18, 28], n: 100, seed: 21 };
const ukCrowd: CrowdSpec = { who: ["ukA", "ukB", "ukC"], center: [12, 0, -4], size: [18, 28], n: 100, seed: 22 };
const campScene = (f: number, hf: (x: number, z: number) => number) => (
  <>
    {Array.from({ length: 7 }, (_, i) => <Cannon key={"c" + i} pos={[-8 - (i % 2) * 2, hf(-8, -22 + i * 5), -22 + i * 5]} rot={0} s={1.1} />)}
    {Array.from({ length: 7 }, (_, i) => <Cannon key={"d" + i} pos={[8 + (i % 2) * 2, hf(8, -22 + i * 5), -22 + i * 5]} rot={Math.PI} s={1.1} />)}
    <Flag pos={[-30, hf(-30, -12), -12]} kind="us" f={f} h={11} /><Flag pos={[30, hf(30, -12), -12]} kind="uk" f={f} h={11} />
    {[0, 1, 2, 3].map((i) => <Tent key={"u" + i} pos={[-36 + (i % 2) * 5, hf(-36, -20 + i * 10), -20 + i * 10]} kind="us" rot={0.3 * i} />)}
    {[0, 1, 2, 3].map((i) => <Tent key={"k" + i} pos={[36 - (i % 2) * 5, hf(36, -20 + i * 10), -20 + i * 10]} kind="uk" />)}
  </>);
const nightCrowds: CrowdSpec[] = [{ who: ["usA", "usB", "usC"], center: [-16, 0, -16], size: [18, 8], n: 28, seed: 31 }, { who: ["ukA", "ukB", "ukC"], center: [16, 0, -16], size: [18, 8], n: 28, seed: 32 }];
const fireScene = (f: number, hf: (x: number, z: number) => number) => <><Campfire pos={[0, hf(0, -2), -2]} f={f} /><Tent pos={[-9, hf(-9, -9), -9]} kind="us" /><Tent pos={[9, hf(9, -9), -9]} kind="uk" /></>;
const fireLight = [{ pos: [0, 1.0, -2] as V3, color: "#ff9a40", intensity: 28, dist: 22 }];
const glareCast: CastItem[] = [{ who: "usA", pos: [-1.15, 0, -2], expr: "glare", pose: "cross", h: 1.85 }, { who: "ukA", pos: [1.15, 0, -2], expr: "glare", pose: "cross", h: 1.85, flip: true }];
const kaiserCast: CastItem[] = [{ who: "kaiser", pos: [0, 0, -4.8], expr: "proud", pose: "hold", h: 1.85, held: { kind: "scroll" } }, { who: "griffin", pos: [-1.5, 0, -3.2], expr: "worried", pose: "cross", h: 1.85 }, { who: "mac", pos: [1.5, 0, -3.2], expr: "worried", pose: "cross", h: 1.8, flip: true }];
const graveCast: CastItem[] = [{ who: "usA", pos: [-1.9, 0, -2.6], expr: "proud", pose: "salute", h: 1.85 }, { who: "ukA", pos: [1.9, 0, -2.6], expr: "proud", pose: "salute", h: 1.85, flip: true }, { who: "mac", pos: [-0.9, 0, -4.6], expr: "worried", h: 1.8 }, { who: "griffin", pos: [1.0, 0, -4.7], expr: "worried", h: 1.85 }];
const graveFlowers = (_f: number, hf: (x: number, z: number) => number) => <>{[0, 1, 2, 3, 4].map((i) => <mesh key={i} position={[-0.6 + i * 0.3, hf(0, -0.5) + 0.12, -0.6 + (i % 2) * 0.2]}><sphereGeometry args={[0.1, 8, 6]} /><meshStandardMaterial color={["#f4a6b6", "#ffd84a", "#ff6b8a", "#ffffff", "#ffd84a"][i]} /></mesh>)}</>;

export const SHOTS: ShotSpec[] = [
  { id: "aerial", start: 0, len: 48, loc: "island", light: "day", focus: [0, 0, -10], shadow: 80, trees: { n: 190, seed: 5, area: 95, minDist: 0, round: 0.25 },
    cam: [{ f: 0, p: [10, 100, 150], t: [0, 0, -10], fov: 55 }, { f: 48, p: [-6, 62, 108], t: [0, 2, -14], fov: 52, roll: 0.03 }], dof: D(150, 120, 90, 1.5), cast: [],
    scene: (f, hf) => <><Flag pos={[-14, hf(-14, -8), -8]} kind="us" f={f} h={20} /><Flag pos={[16, hf(16, -14), -14]} kind="uk" f={f} h={20} /></> },
  { id: "flagsWide", start: 48, len: 50, loc: "meadow", light: "day", focus: [0, 0, -10], shadow: 30, trees: { n: 380, seed: 8, area: 170, minDist: 45 },
    cam: [{ f: 0, p: [0, 1.6, 17], t: [0, 2.6, -18], fov: 50 }, { f: 49, p: [0.3, 1.4, 12.5], t: [0, 2.4, -16], fov: 48 }], dof: D(25, 20, 14, 3),
    cast: [...flagsCast, { who: "pig", pos: [0, 0, -8], expr: "neutral", h: 0.95, bob: 0.03 }], scene: flagsScene },
  { id: "pigClose", start: 98, len: 52, loc: "meadow", light: "day", focus: [0, 0, -8], shadow: 24, trees: { n: 380, seed: 8, area: 170, minDist: 45 },
    cam: [{ f: 0, p: [0.7, 0.7, -2.2], t: [0, 0.75, -8], fov: 42 }, { f: 51, p: [0.3, 0.75, -4.6], t: [0, 0.8, -8], fov: 40 }], dof: D(5.9, 3.7, 3, 5),
    cast: [{ who: "pig", pos: [0, 0, -8], expr: "neutral", h: 0.95, bob: 0.03 }, ...flagsCast], scene: flagsScene },
  { id: "potatoA", start: 150, len: 55, loc: "farm", light: "day", focus: [0, 0, -5], shadow: 26, trees: FT,
    cam: [{ f: 0, p: [-2.2, 0.55, 5], t: [-0.5, 0.8, -8], fov: 48 }, { f: 54, p: [-0.6, 0.6, 3.4], t: [0.6, 0.8, -6], fov: 44 }], dof: D(9, 7.5, 5, 4),
    cast: [{ who: "pig", pos: [-2.6, 0, -3.4], expr: "neutral", h: 1.0, to: [0.7, 0, -4.3], walk: [0, 55] }, { who: "mac", pos: [-5.5, 0, -18], expr: "neutral", h: 1.8 }], scene: farmScene },
  { id: "potatoB", start: 205, len: 38, loc: "farm", light: "day", focus: [2, 0, -5], shadow: 22, trees: FT,
    cam: [{ f: 0, p: [0.2, 0.5, -0.4], t: [2.2, 0.7, -5.2], fov: 40 }, { f: 37, p: [1.0, 0.55, -0.9], t: [2.8, 0.75, -5.2], fov: 38 }], dof: D(5.5, 5, 4, 4.5),
    cast: [{ who: "pig", pos: [0.7, 0, -4.3], expr: "neutral", h: 1.0, to: [3.2, 0, -5.4], walk: [0, 38] }, { who: "mac", pos: [-5.5, 0, -18], expr: "neutral", h: 1.8 }], scene: farmScene },
  { id: "shot", start: 243, len: 39, loc: "farm", light: "day", focus: [0, 0, -4], shadow: 20, trees: FT,
    cam: [{ f: 0, p: [-0.8, 0.5, 3.6], t: [0, 1.5, -2], fov: 40 }, { f: 38, p: [-0.5, 0.7, 3.0], t: [0, 1.6, -2], fov: 36 }], kicks: [8], flash: [{ f: 8, len: 4 }], dof: D(5.7, 5.3, 5, 3),
    cast: [{ who: "mac", pos: [0, 0, -2], expr: "shocked", pose: "hold", h: 1.85, held: { kind: "musket" } }, { who: "pig", pos: [3.5, 0, -9], expr: "neutral", h: 1.0, vis: [0, 8] }, { who: "pig", pos: [3.5, 0, -9], expr: "worried", h: 1.0, vis: [8, 99] }],
    fx: [{ kind: "flash", pos: [1.3, 1.85, -1.9], t0: 8, dur: 4, size: 1.4 }, { kind: "puff", pos: [1.35, 1.9, -2.0], t0: 8, dur: 26, size: 1.5, rise: 0.8 }, { kind: "puff", pos: [1.6, 2.0, -2.2], t0: 10, dur: 26, size: 1.1, rise: 0.6 }], scene: farmScene },
  { id: "ownerA", start: 282, len: 36, loc: "farm", light: "day", focus: [0, 0, -3], shadow: 20, trees: FT,
    cam: [{ f: 0, p: [1.6, 1.2, 2.3], t: [1.2, 1.45, -3], fov: 38 }, { f: 35, p: [1.4, 1.3, 1.6], t: [1.2, 1.5, -3], fov: 35 }], dof: D(5.4, 4.7, 4, 4), cast: ownerCast, scene: farmScene },
  { id: "ownerB", start: 318, len: 33, loc: "farm", light: "day", focus: [0, 0, -4], shadow: 22, trees: FT,
    cam: [{ f: 0, p: [0, 1.0, 6.5], t: [0, 1.0, -4], fov: 42 }, { f: 32, p: [0.1, 1.0, 5.4], t: [0, 1.1, -4], fov: 40 }], dof: D(10, 9, 8, 3.5), cast: ownerCast, scene: farmScene },
  { id: "tenA", start: 351, len: 30, loc: "farm", light: "day", focus: [0, 0, -3], shadow: 20, trees: FT,
    cam: [{ f: 0, p: [-0.9, 1.3, 4.2], t: [-0.3, 1.5, -2], fov: 36 }, { f: 29, p: [-0.6, 1.35, 3.4], t: [-0.3, 1.55, -2], fov: 34 }], dof: D(6.3, 5.5, 5, 3.5), cast: tenCast, scene: farmScene },
  { id: "tenB", start: 381, len: 30, loc: "farm", light: "day", focus: [1, 0, -3], shadow: 20, trees: FT,
    cam: [{ f: 0, p: [1.9, 1.3, 2.7], t: [1.4, 1.5, -3.4], fov: 34 }, { f: 29, p: [1.7, 1.35, 2.2], t: [1.4, 1.55, -3.4], fov: 32 }], dof: D(6.2, 5.6, 5, 3.5), cast: tenCast, scene: farmScene },
  { id: "landingA", start: 411, len: 29, loc: "beach", light: "day", focus: [0, 0, -2], shadow: 24, trees: { n: 420, seed: 3, area: 150, minDist: 30 },
    cam: [{ f: 0, p: [-1.0, 0.7, 6.5], t: [0.5, 0.8, 0], fov: 46 }, { f: 28, p: [-0.4, 0.8, 5], t: [0.8, 0.9, -1], fov: 44 }], dof: D(6.7, 5.5, 5, 3.5),
    cast: [], crowds: [{ who: ["usA", "usB", "usC"], center: [0, 0, -11], size: [9, 8], n: 22, seed: 4, marching: true }], scene: (f, hf) => <>{boats(f)}<Flag pos={[2.5, hf(2.5, -15), -15]} kind="us" f={f} h={7} /></> },
  { id: "landingB", start: 440, len: 34, loc: "beach", light: "day", focus: [0, 0, -6], shadow: 24, trees: { n: 420, seed: 3, area: 150, minDist: 30 },
    cam: [{ f: 0, p: [-4, 1.1, 11], t: [0, 1.5, -8], fov: 48 }, { f: 33, p: [-1.5, 1.4, 8], t: [0.5, 1.6, -8], fov: 44 }], dof: D(14, 12, 12, 3),
    cast: [{ who: "usCap", pos: [-0.6, 0, -6.5], expr: "proud", pose: "salute", h: 1.85 }], crowds: [{ who: ["usA", "usB", "usC"], center: [0, 0, -11], size: [9, 8], n: 22, seed: 4, marching: true }], scene: (f, hf) => <>{boats(f)}<Flag pos={[2.5, hf(2.5, -15), -15]} kind="us" f={f} h={7} /></> },
  { id: "shipsA", start: 474, len: 36, loc: "sea", light: "day", focus: [-16, 0, -38], shadow: 60, trees: { n: 700, seed: 6, area: 480, minDist: 0 },
    cam: [{ f: 0, p: [-12, 3, -22], t: [-16, 6, -38], fov: 50 }, { f: 35, p: [-10, 3.2, -26], t: [-16, 6.5, -38], fov: 48, roll: 0.03 }], dof: D(18, 14, 22, 2), cast: [], scene: (f) => ships(f) },
  { id: "shipsB", start: 510, len: 42, loc: "sea", light: "day", focus: [0, 0, -50], shadow: 70, trees: { n: 700, seed: 6, area: 480, minDist: 0 },
    cam: [{ f: 0, p: [-40, 17, 36], t: [2, 5, -46], fov: 50 }, { f: 41, p: [-24, 9, 16], t: [3, 6, -46], fov: 46, roll: -0.03 }], dof: D(80, 55, 60, 2), cast: [], scene: (f) => ships(f) },
  { id: "crowdA", start: 552, len: 40, loc: "meadow", light: "day", focus: [-12, 0, -4], shadow: 30, trees: { n: 300, seed: 9, area: 140, minDist: 40, round: 0.3 },
    cam: [{ f: 0, p: [-12, 1.4, 6], t: [-12, 1.5, -6], fov: 45 }, { f: 39, p: [-11, 1.4, 3], t: [-12, 1.5, -6], fov: 43 }], dof: D(11, 8, 8, 4),
    cast: [], crowds: [{ ...usCrowd, center: [-12, 0, -11], size: [8, 9], n: 40 }], scene: campScene },
  { id: "crowdB", start: 592, len: 48, loc: "meadow", light: "day", focus: [-6, 0, -8], shadow: 30, trees: { n: 300, seed: 9, area: 140, minDist: 40, round: 0.3 },
    cam: [{ f: 0, p: [-1, 1.6, 12], t: [-6, 1.2, -8], fov: 45 }, { f: 47, p: [-3, 1.4, 6], t: [-6, 1.2, -9], fov: 43 }], dof: D(14, 10, 10, 3), cast: [], crowds: [usCrowd, ukCrowd], scene: campScene },
  { id: "crowdC", start: 640, len: 60, loc: "camp", light: "day", focus: [0, 0, -4], shadow: 60, trees: { n: 260, seed: 9, area: 85, minDist: 40, round: 0.3 },
    cam: [{ f: 0, p: [0, 13, 36], t: [0, 2, -4], fov: 50 }, { f: 59, p: [0, 58, 98], t: [0, 0, -10], fov: 55 }], dof: D(38, 110, 40, 2.5), cast: [], crowds: [usCrowd, ukCrowd], scene: campScene },
  { id: "glareA", start: 700, len: 40, loc: "meadow", light: "night", focus: [0, 0, -2], shadow: 22, trees: { n: 220, seed: 9, area: 85, minDist: 30, round: 0.3 },
    cam: [{ f: 0, p: [-1.7, 1.25, 3.3], t: [-1.1, 1.45, -2], fov: 34 }, { f: 39, p: [-1.45, 1.3, 2.8], t: [-1.1, 1.5, -2], fov: 32 }], dof: D(5.7, 5.2, 4, 4), extraLights: fireLight, cast: glareCast, crowds: nightCrowds, scene: fireScene },
  { id: "glareB", start: 740, len: 35, loc: "meadow", light: "night", focus: [0, 0, -2], shadow: 22, trees: { n: 220, seed: 9, area: 85, minDist: 30, round: 0.3 },
    cam: [{ f: 0, p: [1.7, 1.25, 3.3], t: [1.1, 1.45, -2], fov: 34 }, { f: 34, p: [1.45, 1.3, 2.8], t: [1.1, 1.5, -2], fov: 32 }], dof: D(5.7, 5.2, 4, 4), extraLights: fireLight, cast: glareCast, crowds: nightCrowds, scene: fireScene },
  { id: "glareC", start: 775, len: 26, loc: "meadow", light: "night", focus: [0, 0, -2], shadow: 22, trees: { n: 220, seed: 9, area: 85, minDist: 30, round: 0.3 },
    cam: [{ f: 0, p: [0, 0.9, 5.2], t: [0, 1.2, -2], fov: 40 }, { f: 25, p: [0, 1.0, 4.4], t: [0, 1.25, -2], fov: 38 }], dof: D(7.2, 6.4, 5, 3.5), extraLights: fireLight, cast: glareCast, crowds: nightCrowds, scene: fireScene },
  { id: "hallwide", start: 801, len: 45, loc: "hall", light: "day", focus: [0, 0, -3], shadow: 16,
    cam: [{ f: 0, p: [0, 4.2, 17], t: [0, 3.4, -4], fov: 40 }, { f: 44, p: [0, 3.2, 12], t: [0, 2.6, -4], fov: 40 }], dof: D(20, 15, 14, 2.5), cast: [{ who: "kaiser", pos: [0, 0, -5.0], expr: "neutral", h: 1.8, bob: 0.01 }] },
  { id: "kaiserA", start: 846, len: 34, loc: "hall", light: "day", focus: [0, 0, -4], shadow: 14,
    cam: [{ f: 0, p: [0, 1.2, 0.6], t: [0, 1.8, -4.8], fov: 32 }, { f: 33, p: [0.1, 1.4, -0.4], t: [0, 1.85, -4.8], fov: 30 }], dof: D(5.5, 4.8, 3.5, 4), cast: kaiserCast },
  { id: "kaiserB", start: 880, len: 44, loc: "hall", light: "day", focus: [0, 0, -3], shadow: 14,
    cam: [{ f: 0, p: [0, 0.9, 3.4], t: [0, 1.7, -4], fov: 38 }, { f: 43, p: [0.2, 1.2, 2.0], t: [0, 1.8, -4], fov: 34 }], kicks: [4], dof: D(8, 6.6, 4.5, 3.5), cast: kaiserCast,
    fx: [{ kind: "spark", pos: [0.9, 1.1, -4.6], t0: 4, dur: 12, size: 1.1 }, { kind: "puff", pos: [0.8, 1.0, -4.6], t0: 4, dur: 18, size: 0.8, rise: 0.4 }] },
  { id: "graveA", start: 924, len: 31, loc: "hill", light: "golden", focus: [0, 0, -2], shadow: 14, trees: { n: 380, seed: 17, area: 170, minDist: 40 },
    cam: [{ f: 0, p: [0, 0.95, 4.4], t: [0, 1.25, -1.8], fov: 40 }, { f: 30, p: [0, 1.05, 5.4], t: [0, 1.35, -1.8], fov: 40 }], dof: D(6.2, 7.2, 4, 4), cast: graveCast, scene: graveFlowers },
  { id: "graveB", start: 955, len: 30, loc: "hill", light: "golden", focus: [0, 0, -2], shadow: 14, trees: { n: 380, seed: 17, area: 170, minDist: 40 },
    cam: [{ f: 0, p: [0, 1.2, 7.5], t: [0, 1.0, -2.5], fov: 40 }, { f: 29, p: [0, 2.6, 13], t: [0, 1.1, -2.5], fov: 42 }], dof: D(10, 15, 8, 3), cast: graveCast, scene: graveFlowers },
];
export const heightOf = (loc: Loc) => heightFn(loc);
